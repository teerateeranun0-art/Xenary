const express = require("express");

const router = express.Router();

router.get("/", (req, res) => {
  res.set("Cache-Control", "no-store").json({ ok: true, status: "healthy" });
});

module.exports = router;
