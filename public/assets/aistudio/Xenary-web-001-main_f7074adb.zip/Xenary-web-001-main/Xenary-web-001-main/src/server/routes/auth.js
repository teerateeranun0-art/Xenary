const crypto = require("node:crypto");
const express = require("express");
const store = require("../lib/store");
const auth = require("../lib/auth");
const captcha = require("../lib/captcha");
const asyncRoute = require("../lib/async-route");

const router = express.Router();
const tries = new Map();   // per-IP request throttle
const fails = new Map();   // per-account failed logins
const DUMMY = auth.hashPassword("dummy-password");
const MAX_FAILS = 5, LOCK_MS = 5 * 60 * 1000;
const TURNSTILE_SECRET = process.env.TURNSTILE_SECRET_KEY || "";

router.get("/config", (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ turnstile: Boolean(TURNSTILE_SECRET) });
});

const recent = (ip) => (tries.get(ip) || []).filter((t) => Date.now() - t < 60000);
const blocked = (ip) => recent(ip).length >= 10;
const hit = (ip) => {
  if (tries.size > 2000) {
    const now = Date.now();
    for (const [k, arr] of tries.entries()) {
      if (!arr.some((t) => now - t < 60000)) tries.delete(k);
    }
    if (tries.size > 2000) tries.clear();
  }
  tries.set(ip, [...recent(ip), Date.now()]);
};
const bad = (res, status, error, message) => res.status(status).json({ error, message });

async function verifyTurnstile(response) {
  if (!TURNSTILE_SECRET || !response) return false;
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 6000);
  try {
    const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ secret: TURNSTILE_SECRET, response })
    });
    const json = await r.json();
    return !!json.success;
  } catch (err) {
    console.warn("[turnstile] verification failed", err.message || err);
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function botCheck(req, res) {
  const b = req.body || {};
  if (b.website) { bad(res, 400, "bad_captcha", "รหัสยืนยันไม่ถูกต้อง"); return false; }
  const remoteAddr = String(req.socket?.remoteAddress || req.ip || "");
  const isLoopback = remoteAddr === "127.0.0.1" || remoteAddr === "::1" || remoteAddr === "::ffff:127.0.0.1";
  if (isLoopback && process.env.NODE_ENV !== "production") return true;

  const token = String(b["cf-turnstile-response"] || b.turnstileToken || b.turnstile_response || "").trim();
  if (TURNSTILE_SECRET) {
    if (!token || !(await verifyTurnstile(token))) {
      bad(res, 400, "bad_captcha", "รหัสยืนยันไม่ถูกต้อง กรุณาลองใหม่");
      return false;
    }
    return true;
  }
  if (b.captchaId) {
    if (!captcha.verify(b.captchaId, b.captchaAnswer)) { bad(res, 400, "bad_captcha", "รหัสยืนยันไม่ถูกต้อง กรุณาลองใหม่"); return false; }
  }
  return true;
}

router.get("/captcha", (req, res) => {
  if (blocked(req.ip)) return bad(res, 429, "too_many", "ลองบ่อยเกินไป รอสักครู่");
  hit(req.ip);
  res.set("Cache-Control", "no-store");
  res.json(captcha.create());
});

router.post("/register", asyncRoute(async (req, res) => {
  const b = req.body || {};
  const username = String(b.username || "").trim();
  const password = String(b.password || "");
  if (blocked(req.ip)) return bad(res, 429, "too_many", "ลองบ่อยเกินไป รอสักครู่");
  if (!(await botCheck(req, res))) return;
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return bad(res, 400, "bad_username", "ชื่อผู้ใช้ 3-20 ตัว ใช้ a-z 0-9 _ เท่านั้น");
  if (password.length < 8 || password.length > 72) return bad(res, 400, "bad_password", "รหัสผ่านต้องยาว 8-72 ตัวอักษร");
  hit(req.ip);
  const user = { id: "U" + crypto.randomBytes(6).toString("hex"), username, pass: auth.hashPassword(password), balance: 0, createdAt: new Date().toISOString() };
  const created = await store.withLock("wallet-ledger", async () => {
    const users = await store.users();
    if (users.some((u) => String(u.username || "").toLowerCase() === username.toLowerCase())) return false;
    users.push(user);
    await store.writeUsers(users);
    return true;
  });
  if (!created) return bad(res, 409, "username_taken", "ชื่อผู้ใช้นี้ถูกใช้แล้ว");
  await auth.createSession(res, user.id, !!b.remember);
  res.status(201).json({ user: auth.publicUser(user) });
}));

router.post("/login", asyncRoute(async (req, res) => {
  const b = req.body || {};
  const username = String(b.username || "").trim();
  const password = String(b.password || "");
  const key = username.toLowerCase();
  if (blocked(req.ip)) return bad(res, 429, "too_many", "ลองบ่อยเกินไป รอสักครู่");
  if (!(await botCheck(req, res))) return;
  const f = fails.get(key);
  if (f && f.until > Date.now()) return bad(res, 429, "locked", "ใส่รหัสผิดหลายครั้ง บัญชีถูกล็อกชั่วคราว ลองใหม่ใน " + Math.ceil((f.until - Date.now()) / 60000) + " นาที");
  const user = (await store.users()).find((u) => String(u.username || "").toLowerCase() === key);
  const ok = auth.verifyPassword(password, user ? user.pass : DUMMY) && user;
  if (!ok) {
    hit(req.ip);
    if (fails.size > 2000) {
      const now = Date.now();
      for (const [fk, fv] of fails.entries()) {
        if (fv.until && fv.until <= now) fails.delete(fk);
      }
      if (fails.size > 2000) fails.clear();
    }
    const expired = f && f.until && f.until <= Date.now();
    const n = (expired ? 0 : f ? f.n : 0) + 1;
    fails.set(key, { n, until: n >= MAX_FAILS ? Date.now() + LOCK_MS : 0 });
    return bad(res, 401, "bad_login", "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
  }
  fails.delete(key);
  if (user.banned) {
    return bad(res, 403, "account_banned", "บัญชีของคุณถูกระงับการใช้งาน" + (user.ban_reason ? " (" + user.ban_reason + ")" : ""));
  }
  await auth.createSession(res, user.id, !!b.remember);
  res.json({ user: auth.publicUser(user) });
}));

router.post("/logout", asyncRoute(async (req, res) => { await auth.destroySession(req, res); res.json({ ok: true }); }));
router.get("/me", (req, res) => res.json({ user: req.user ? auth.publicUser(req.user) : null }));

module.exports = router;
