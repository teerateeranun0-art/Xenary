// Manual topup (slip-based) routes
const express = require("express");
const asyncRoute = require("../lib/async-route");
const auth = require("../lib/auth");
const store = require("../lib/store");

const router = express.Router();

// ---- Public: list payment channels ----
router.get("/channels", asyncRoute(async (req, res) => {
  const allChannels = await store.paymentChannels();
  const channels = (allChannels || []).filter((c) => c.enabled !== false);
  res.json({ channels });
}));

// ---- Auth required below ----
router.use(auth.requireAuth);

// GET /api/manual-topup – list own requests
router.get("/", asyncRoute(async (req, res) => {
  const allTopups = await store.manualTopups();
  const list = (allTopups || [])
    .filter((t) => t.user_id === req.user.id)
    .slice(-30)
    .reverse();
  res.json({ topups: list });
}));

// POST /api/manual-topup – create request
router.post("/", asyncRoute(async (req, res) => {
  const s = store.settings ? await store.settings() : {};
  if ((s.topup_mode === "disabled" || s.maintenance) && (!req.user || req.user.role !== "admin")) {
    return res.status(503).json({ error: "topup_disabled", message: "ระบบเติมเงินกำลังปิดปรับปรุงชั่วคราว" });
  }
  const b = req.body || {};
  const channelId = String(b.channel_id || "").trim();
  const amount = Math.round(Number(b.amount) * 100) / 100;
  const slipUrl = typeof b.slip_url === "string" ? b.slip_url.trim().slice(0, 2000000) : null;
  const qrPayload = typeof b.qr_payload === "string" ? b.qr_payload.trim().slice(0, 1000) : null;

  if (!Number.isFinite(amount) || amount < 1 || amount > 200000) {
    return res.status(400).json({ error: "bad_amount", message: "กรุณาระบุจำนวนเงินที่โอน (ขั้นต่ำ 1 บาท สูงสุด 200,000 บาท)" });
  }
  if (!slipUrl && !qrPayload) {
    return res.status(400).json({ error: "missing_slip", message: "กรุณาอัปโหลดรูปภาพสลิป หรือวาง Payload จาก QR Code" });
  }
  if (slipUrl && !/^(data:image\/(png|jpe?g|webp|gif);base64,|https?:\/\/)/i.test(slipUrl)) {
    return res.status(400).json({ error: "invalid_slip_format", message: "รูปแบบไฟล์สลิปไม่ถูกต้อง (รองรับเฉพาะไฟล์รูปภาพ PNG, JPG, WEBP)" });
  }

  return store.withLock("manual-topups-ledger", async () => {
    const list = await store.manualTopups();

    // Prevent spam: max 5 pending requests per user at a time
    const userPending = list.filter((t) => t.user_id === req.user.id && t.status === "pending").length;
    if (userPending >= 5) {
      return res.status(429).json({
        error: "too_many_pending",
        message: "คุณมีรายการแจ้งโอนที่รอตรวจสอบครบ 5 รายการแล้ว กรุณารอแอดมินตรวจสอบสักครู่",
      });
    }

    // Prevent duplicate QR payload or identical slip submission
    if (qrPayload && list.some((t) => t.qr_payload === qrPayload && t.status !== "rejected")) {
      return res.status(409).json({ error: "duplicate_slip", message: "สลิปหรือ QR Code นี้เคยถูกส่งเข้าระบบไปแล้ว" });
    }
    if (slipUrl && slipUrl.length > 64 && list.some((t) => t.slip_url === slipUrl && t.status !== "rejected")) {
      return res.status(409).json({ error: "duplicate_slip", message: "รูปสลิปนี้เคยถูกส่งเข้าระบบไปแล้ว" });
    }

    const rawChannels = await store.paymentChannels();
    const allChannels = (rawChannels || []).filter((c) => c.enabled !== false);
    const channel =
      allChannels.find((c) => String(c.id) === channelId) ||
      allChannels[0] || {
        id: "ch_kbank_default",
        name: "กสิกรไทย (KBank)",
        account_no: "146-8-73566-7",
        account_name: "XENARY STORE",
      };

    const item = {
      id: "mt_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      user_id: req.user.id,
      username: req.user.username,
      channel_id: channel.id,
      channel_name: channel.name,
      amount,
      slip_url: slipUrl || qrPayload || null,
      qr_payload: qrPayload || null,
      status: "pending",
      admin_note: null,
      created_at: new Date().toISOString(),
    };

    list.push(item);
    await store.writeManualTopups(list);

    return res.status(201).json({ ok: true, id: item.id, topup: item });
  });
}));

module.exports = router;
