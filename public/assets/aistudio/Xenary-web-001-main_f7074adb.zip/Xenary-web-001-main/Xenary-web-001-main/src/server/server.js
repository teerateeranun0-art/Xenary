// Runtime: Node.js 18+ (Express 4.x on Vercel Serverless / Local)
// Gotcha: Vercel Edge Cache checks User-Agent variance; header must explicitly specify Vary

require("./lib/env");
const path = require("node:path");
const fs = require("node:fs");
const express = require("express");

const productsRoutes = require("./routes/products").router;
const ordersRoutes = require("./routes/orders");
const statusRoutes = require("./routes/status");
const healthRoutes = require("./routes/health");
const authRoutes = require("./routes/auth");
const walletRoutes = require("./routes/wallet");
const adminRoutes = require("./routes/admin");
const newsRoutes = require("./routes/news");
const supportRoutes = require("./routes/support");
const couponRoutes = require("./routes/coupon");
const manualTopupRoutes = require("./routes/manual-topup");
const auth = require("./lib/auth");

const SITE_ROOT = path.resolve(__dirname, "..", "..");
const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.set("etag", false);

app.use(express.json({ limit: "100kb" }));

const CSP_POLICY = [
  "default-src 'self'",
  "script-src 'self' https://challenges.cloudflare.com https://www.youtube.com https://s.ytimg.com",
  "style-src 'self' https://fonts.googleapis.com",
  "img-src 'self' data: https://img2.pic.in.th https://i.ytimg.com https://*.ytimg.com",
  "font-src 'self' https://fonts.gstatic.com",
  "connect-src 'self' https://challenges.cloudflare.com https://www.youtube.com https://*.supabase.co wss://*.supabase.co",
  "frame-src 'self' https://challenges.cloudflare.com https://www.youtube.com https://www.youtube-nocookie.com",
  "child-src 'self' https://challenges.cloudflare.com https://www.youtube.com https://www.youtube-nocookie.com",
  "media-src 'self'",
  "object-src 'none'",
  "worker-src 'self'",
  "manifest-src 'self'",
  "frame-ancestors 'self'",
  "form-action 'self'",
  "base-uri 'self'",
].join("; ");

// 1. Uniform Security & User-Agent Fuzzer Normalization Headers
app.use((req, res, next) => {
  res.set({
    "Content-Security-Policy": CSP_POLICY,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Permitted-Cross-Domain-Policies": "none",
    "Cross-Origin-Opener-Policy": "same-origin-allow-popups",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
    "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
    "Pragma": "no-cache",
    "Expires": "0",
    "Vary": "Accept-Encoding, User-Agent",
  });
  next();
});

// 2. Strict Internal Paths & File Extension Shield
const BLOCKED_REGEX = /^\/(node_modules|\.git|package(-lock)?\.json|\.env.*|src\/server|src\/data|data|supabase|scripts|tests)(\/|$)/i;
app.use((req, res, next) => {
  let cleanPath = req.path || "/";
  try {
    cleanPath = decodeURIComponent(cleanPath).replace(/\\/g, "/");
  } catch {
    return res.status(400).end();
  }

  if (
    cleanPath.includes("..") ||
    BLOCKED_REGEX.test(cleanPath) ||
    (/^\/src(\/|$)/i.test(cleanPath) && !/^\/src\/client\/.*\.(js|css|png|jpg|jpeg|webp|svg)$/i.test(cleanPath)) ||
    /\.(json|sql|md|env|yml|yaml)$/i.test(cleanPath)
  ) {
    return res.status(404).type("text/plain; charset=utf-8").send("404 Not Found");
  }
  next();
});

// 3. CORS & Origin Validation
app.use((req, res, next) => {
  const configuredOrigin = (process.env.ORIGIN || "").trim();
  const reqOrigin = String(req.headers.origin || "").trim();
  const reqHost = String(req.headers.host || "").trim().toLowerCase();

  let isAllowedOrigin = false;
  if (reqOrigin) {
    if (configuredOrigin && reqOrigin === configuredOrigin) {
      isAllowedOrigin = true;
    } else {
      try {
        const parsedOrigin = new URL(reqOrigin);
        if (parsedOrigin.host.toLowerCase() === reqHost) {
          isAllowedOrigin = true;
        }
      } catch {}
    }
  }

  if (reqOrigin && isAllowedOrigin) {
    res.set("Access-Control-Allow-Origin", reqOrigin);
    res.set("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type,x-admin-key,X-Requested-With");
  }

  if (req.method === "OPTIONS") return res.sendStatus(204);

  if (req.path.startsWith("/api/") && ["POST", "PUT", "PATCH", "DELETE"].includes(req.method) && reqOrigin && !isAllowedOrigin) {
    return res.status(403).json({ error: "csrf_origin_mismatch", message: "ไม่อนุญาตให้ส่งคำขอข้ามโดเมน" });
  }

  next();
});

// 4. Session & Authentication
app.use((req, res, next) => {
  auth.attach(req, res).then(() => next()).catch(next);
});

// 5. API Routes
app.use("/health", healthRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/status", statusRoutes);
app.use("/api/products", productsRoutes);
app.use("/api/orders", ordersRoutes);
app.use("/api/news", newsRoutes);
app.use("/api/support", supportRoutes);
app.use("/api/coupon", couponRoutes);
app.use("/api/manual-topup", manualTopupRoutes);

// 6. Direct Page Routing (Neutralizes Directory Listing & Trailing Slash Differences)
const KNOWN_PAGES = ["/account", "/products", "/status", "/tos", "/contact", "/login", "/register", "/admin"];
app.use((req, res, next) => {
  if (req.method === "GET" || req.method === "HEAD") {
    const p = req.path.replace(/\/+$/, "");
    if (KNOWN_PAGES.includes(p)) {
      const targetFile = path.join(SITE_ROOT, p.slice(1), "index.html");
      if (fs.existsSync(targetFile)) {
        res.set("Content-Type", "text/html; charset=utf-8");
        return res.sendFile(targetFile);
      }
    }
  }
  next();
});

// 7. Static Assets
app.use(
  express.static(SITE_ROOT, {
    index: ["index.html"],
    redirect: false,
    etag: false,
    lastModified: false,
    maxAge: 0,
  })
);

// 8. 404 Handlers
app.use("/api", (req, res) => res.status(404).json({ error: "unknown_endpoint" }));
app.use((req, res) => res.status(404).type("text/plain; charset=utf-8").send("404 Not Found"));

// 9. Error Handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err && err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "invalid_json", message: "ข้อมูลที่ส่งมาไม่ถูกต้อง" });
  }
  if (err && (err.type === "entity.too.large" || err.status === 413)) {
    return res.status(413).json({ error: "payload_too_large", message: "ขนาดข้อมูลเกินกำหนด" });
  }
  if (err && err.status && err.status < 500) {
    return res.status(err.status).json({ error: err.code || "bad_request", message: err.message });
  }
  return res.status(500).json({ error: "server_error", message: "เกิดข้อผิดพลาดภายในระบบ" });
});

if (require.main === module || !process.env.VERCEL) {
  app.listen(PORT, () => {
    console.log(`[XENARY] Local server running on http://localhost:${PORT}`);
  });
}

module.exports = app;