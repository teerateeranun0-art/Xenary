// GET /api/support – list active support & contact channels (public)
const express = require("express");
const asyncRoute = require("../lib/async-route");
const store = require("../lib/store");

const router = express.Router();

router.get("/", asyncRoute(async (req, res) => {
  const s = await store.settings();
  const rawLinks = await store.supportLinks();
  const links = (rawLinks || [])
    .filter((item) => item && item.enabled !== false)
    .sort((a, b) => (Number(a.sort_order) || 99) - (Number(b.sort_order) || 99));

  res.json({
    site_name: s.site_name || "XENARY",
    discord_url: s.discord_url || "",
    links,
  });
}));

module.exports = router;
