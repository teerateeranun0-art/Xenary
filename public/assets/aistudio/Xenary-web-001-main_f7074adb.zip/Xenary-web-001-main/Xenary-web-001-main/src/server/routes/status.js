const express = require("express");
const store = require("../lib/store");
const asyncRoute = require("../lib/async-route");

const router = express.Router();
const startedAt = Date.now();

// GET /api/status
router.get("/", asyncRoute(async (req, res) => {
  const { products, updatedAt } = await store.catalog();
  const orders = await store.orders();
  const s = store.settings ? await store.settings() : {};
  const list = products || [];
  res.json({
    store: s.site_name || "XENARY",
    online: !s.maintenance,
    maintenance: Boolean(s.maintenance),
    uptimeSec: 3600,
    products: list.length,
    updatingCount: list.filter((p) => p.updating || p.status_mode === "updating").length,
    orders: orders.length,
    paid: orders.filter((o) => o.status === "paid" || o.status === "delivered").length,
    pending: orders.filter((o) => o.status === "pending").length,
    items: list.map((p) => ({
      slug: p.slug,
      name: p.name,
      tag: p.tag,
      img: p.img,
      stock: p.stock || 0,
      updating: Boolean(p.updating || p.status_mode === "updating"),
      update_note: p.update_note || "",
      updatedAt: p.updatedAt || updatedAt || "2026-10-21",
    })),
    updatedAt: updatedAt || "2026-10-21",
  });
}));

module.exports = router;
