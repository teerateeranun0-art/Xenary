const crypto = require("node:crypto");
const express = require("express");
const store = require("../lib/store");
const { planOf } = require("./products");
const auth = require("../lib/auth");
const asyncRoute = require("../lib/async-route");

const router = express.Router();

const findProduct = async (ref) => {
  const { products } = await store.catalog();
  return (products || []).find(
    (p) =>
      p.slug === ref ||
      p.id === ref ||
      p.channel === ref ||
      String(p.name || "").toLowerCase() === String(ref || "").toLowerCase()
  );
};

const orderId = () =>
  "ORD-" +
  new Date().toISOString().slice(0, 10).replace(/-/g, "") +
  "-" +
  crypto.randomBytes(4).toString("hex").toUpperCase();

// POST /api/orders
router.post("/", auth.requireAuth, async (req, res, next) => {
  const s = store.settings ? await store.settings() : {};
  if (s.maintenance && (!req.user || req.user.role !== "admin")) {
    return res.status(503).json({
      error: "maintenance_mode",
      message: "ขณะนี้ร้านค้ากำลังปิดปรับปรุงระบบชั่วคราว กรุณาลองใหม่อีกครั้งภายหลัง",
    });
  }
  store.withLock("wallet-ledger", async () => {
    const { product, plan, quantity = 1, contact } = req.body || {};

    const item = await findProduct(product);
    if (!item) {
      return res.status(400).json({ error: "unknown_product", field: "product", message: "ไม่พบสินค้านี้ในระบบ" });
    }
    if (item.updating || item.status_mode === "updating") {
      return res.status(409).json({
        error: "product_updating",
        message: "สินค้านี้กำลังปิดอัปเดตชั่วคราว" + (item.update_note ? " (" + item.update_note + ")" : " กรุณารอการอัปเดตเสร็จสิ้น"),
      });
    }

    const chosen = planOf(item, plan) || (item.plans && item.plans[0]);
    if (!chosen) {
      return res.status(400).json({
        error: "unknown_plan",
        field: "plan",
        message: "ไม่พบแพ็กเกจราคาที่เลือก",
        allowed: Array.isArray(item.plans) && item.plans.length ? item.plans.map((p) => p && p.label).filter(Boolean) : ["มาตรฐาน"],
      });
    }

    const qty = Number(quantity);
    if (!Number.isInteger(qty) || qty < 1 || qty > 10) {
      return res.status(400).json({
        error: "bad_quantity",
        field: "quantity",
        allowed: "1..10",
        message: "จำนวนที่สั่งซื้อต้องอยู่ระหว่าง 1 ถึง 10 ชิ้น",
      });
    }

    // Stock is strictly counted from unused keys in stock
    const allKeys = await store.keys();
    const exactPlanKeys = allKeys.filter(
      (k) =>
        (k.product_id === item.slug || k.product_id === item.id) &&
        !k.is_used &&
        k.plan_label === chosen.label
    );
    const universalKeys = allKeys.filter(
      (k) =>
        (k.product_id === item.slug || k.product_id === item.id) &&
        !k.is_used &&
        !k.plan_label
    );
    const candidateKeys = [...exactPlanKeys, ...universalKeys];
    const availableCount = candidateKeys.length;

    if (availableCount === 0) {
      return res.status(409).json({
        error: "out_of_stock",
        message: "สินค้าแพ็กเกจ '" + chosen.label + "' หมดสต็อกแล้ว (ไม่มีคีย์คงเหลือ)",
      });
    }
    if (qty > availableCount) {
      return res.status(409).json({
        error: "insufficient_stock",
        message: "คีย์สำหรับแพ็กเกจ '" + chosen.label + "' เหลือเพียง " + availableCount + " คีย์",
        available: availableCount,
      });
    }

    const rawPrice = Number(chosen.price);
    const unitPrice = Math.round(rawPrice * 100) / 100;
    const total = Math.round(unitPrice * qty * 100) / 100;
    if (!Number.isFinite(rawPrice) || rawPrice <= 0) {
      return res.status(400).json({ error: "invalid_product_price", product: item.slug, message: "ราคาสินค้าไม่ถูกต้อง" });
    }

    const catalog = await store.catalog();
    const users = await store.users();
    const userIdx = users.findIndex((u) => u.id === req.user.id);
    const user = users[userIdx];
    const balance = Number(user && user.balance) || 0;
    if (!user || balance < total) {
      return res.status(402).json({
        error: "insufficient_balance",
        message: "ยอดเงินในกระเป๋าไม่เพียงพอ กรุณาเติมเงินก่อนสั่งซื้อ",
        balance,
        need: total,
      });
    }

    const now = new Date().toISOString();
    const newOrderId = orderId();

    // Pick keys from stock and mark as used
    const picked = candidateKeys.slice(0, qty);
    const pickedIds = new Set(picked.map((k) => k.id));
    allKeys.forEach((k) => {
      if (pickedIds.has(k.id)) {
        k.is_used = true;
        k.order_id = newOrderId;
        k.used_at = now;
      }
    });
    await store.writeKeys(allKeys);
    const deliveredKeys = picked.map((k) => k.key_value);

    // Update product stock from remaining unused keys and increment sold count
    const remainingKeys = allKeys.filter(
      (k) => (k.product_id === item.slug || k.product_id === item.id) && !k.is_used
    ).length;
    const nextSold = (Number(item.sold) || 0) + qty;
    await store.saveProduct({ ...item, stock: remainingKeys, sold: nextSold }, item.slug);

    const downloadUrl = String(item.download_url || "").trim() || null;

    const order = {
      id: newOrderId,
      status: "delivered",
      userId: user.id,
      product: {
        slug: item.slug || item.id,
        name: item.name,
        tag: item.tag,
        download_url: downloadUrl,
      },
      plan: { label: chosen.label, per: chosen.per || ("/" + chosen.label) },
      unitPrice,
      quantity: qty,
      total,
      currency: catalog.currencySymbol || "฿",
      contact: contact ? String(contact).slice(0, 64) : user.username,
      keys_delivered: deliveredKeys,
      download_url: downloadUrl,
      createdAt: now,
      paidAt: now,
    };

    const previousBalance = user.balance;
    const previousSold = Number(item.sold) || 0;
    const previousStock = Number(item.stock) || 0;
    user.balance = Math.round((balance - total) * 100) / 100;
    user.updatedAt = now;

    try {
      await store.writeUsers(users);
      await store.syncUserRowToSupabase(user);
      await store.saveOrder(order);
    } catch (error) {
      // Full atomic rollback: restore user balance, restore key status, and restore product stock/sold
      user.balance = previousBalance;
      await store.writeUsers(users);
      allKeys.forEach((k) => {
        if (pickedIds.has(k.id)) {
          k.is_used = false;
          k.order_id = null;
          delete k.used_at;
        }
      });
      await store.writeKeys(allKeys);
      await store.saveProduct({ ...item, stock: previousStock, sold: previousSold }, item.slug).catch(() => {});
      return res.status(503).json({ error: "purchase_unavailable", message: "บันทึกคำสั่งซื้อไม่สำเร็จ ระบบคืนยอดเงินและคีย์สินค้าแล้ว" });
    }

    res.status(201).json({
      ...order,
      balance: user.balance,
      ticket: (catalog.checkout || {}).ticket,
      keys: deliveredKeys,
      download_url: downloadUrl,
    });
  }).catch(next);
});

// GET /api/orders/recent
router.get("/recent", asyncRoute(async (req, res) => {
  const limit = Math.min(Number.parseInt(req.query.limit, 10) || 8, 20);
  const list = (await store.orders())
    .filter((o) => ["paid", "delivered", "completed"].includes(o.status))
    .slice(-limit)
    .reverse()
    .map((o) => ({
      slug: o.product && (o.product.slug || o.product.id),
      name: (o.product && o.product.name) || "สินค้า",
      total: o.total,
      createdAt: o.createdAt,
      buyer: String(o.contact || "user").replace(/#.*/, "").slice(0, 3) + "***",
    }));
  res.json({ count: list.length, orders: list });
}));

// GET /api/orders/mine
router.get("/mine", auth.requireAuth, asyncRoute(async (req, res) => {
  const list = (await store.orders())
    .filter((o) => o.userId === req.user.id)
    .slice(-30)
    .reverse();

  const allKeys = await store.keys();
  const cat = await store.catalog();
  const prodBySlug = new Map((cat.products || []).map((p) => [p.slug, p]));

  res.json({
    orders: list.map((o) => {
      const matchedKeys = allKeys.filter((k) => k.order_id === o.id).map((k) => k.key_value);
      const keys = Array.isArray(o.keys_delivered) && o.keys_delivered.length ? o.keys_delivered : matchedKeys;
      const pSlug = o.product && (o.product.slug || o.product.id);
      const liveProd = pSlug ? prodBySlug.get(pSlug) : null;
      const dlUrl = o.download_url || (o.product && o.product.download_url) || (liveProd && liveProd.download_url) || null;
      return {
        id: o.id,
        status: o.status,
        product: o.product,
        plan: o.plan,
        quantity: o.quantity,
        total: o.total,
        currency: o.currency || "฿",
        createdAt: o.createdAt,
        keys,
        download_url: dlUrl,
      };
    }),
  });
}));

module.exports = router;
