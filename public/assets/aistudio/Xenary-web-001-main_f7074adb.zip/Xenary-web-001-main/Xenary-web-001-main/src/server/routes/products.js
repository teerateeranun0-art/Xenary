// ================================================================
// ไฟล์ที่ 5: src/server/routes/products.js (โค้ดเต็ม 100%)
// ================================================================
const express = require("express");
const store = require("../lib/store");
const asyncRoute = require("../lib/async-route");

const router = express.Router();

router.get(
  "/",
  asyncRoute(async (req, res) => {
    let cat = await store.catalog();

    const products = (cat && Array.isArray(cat.products)) ? cat.products : [];

    const publicProducts = products.map((p) => {
      const from = Number.isFinite(p.from) ? p.from : (Number(p.price) || 0);
      return {
        slug: p.slug,
        id: p.id || p.slug,
        channel: p.channel || p.slug,
        name: p.name,
        tag: p.tag || "General",
        desc: p.desc || "",
        stock: Number(p.stock) || 0,
        sold: Number(p.sold) || 0,
        bestSeller: Boolean(p.bestSeller),
        featured: Boolean(p.featured),
        key_based: true,
        img: p.img || "https://img2.pic.in.th/serifaimcolor3.png",
        plans: Array.isArray(p.plans) ? p.plans : [],
        download_url: p.download_url || "",
        unused_keys: Number(p.stock) || 0,
        from,
        updating: Boolean(p.updating || p.status_mode === "updating"),
        status_mode: (p.updating || p.status_mode === "updating") ? "updating" : "normal",
        update_note: p.update_note || "",
        updatedAt: p.updatedAt || new Date().toISOString().slice(0, 10),
      };
    });

    res.json({
      count: publicProducts.length,
      currency: "฿",
      currencyCode: "THB",
      updatedAt: cat ? (cat.updatedAt || new Date().toISOString().slice(0, 10)) : "2026-10-22",
      checkout: {
        ticket: "/contact/",
        note: "Orders land as a Discord ticket until the payment gateway is connected.",
      },
      products: publicProducts,
    });
  })
);

router.get(
  "/:slug",
  asyncRoute(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const cat = await store.catalog();
    const p = (cat.products || []).find((x) => x.slug === slug || x.id === slug);

    if (!p) {
      return res.status(404).json({ error: "not_found", message: "ไม่พบสินค้านี้" });
    }

    res.json({
      product: {
        ...p,
        stock: Number(p.stock) || 0,
        sold: Number(p.sold) || 0,
        from: Number(p.from) || 0,
        plans: Array.isArray(p.plans) ? p.plans : [],
      },
    });
  })
);

module.exports = { router };