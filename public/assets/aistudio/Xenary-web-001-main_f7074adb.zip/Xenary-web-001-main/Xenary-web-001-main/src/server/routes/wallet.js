const crypto = require("node:crypto");
const express = require("express");
const store = require("../lib/store");
const auth = require("../lib/auth");
const pp = require("../lib/promptpay");
const tm = require("../lib/truemoney");
const asyncRoute = require("../lib/async-route");

let QR = null;
try { QR = require("qrcode"); } catch {}

const router = express.Router();
router.use(auth.requireAuth);
const DEMO = process.env.DEMO_PAYMENTS === "1";
const PP_MIN_MS = 30 * 60 * 1000;

const topups = async () => store.topups();
const id = (p) => p + crypto.randomBytes(5).toString("hex").toUpperCase();
const err = (res, status, error, message) => res.status(status).json({ error, message });

async function credit(uid, amount) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("invalid_credit_amount");
  return store.withLock("wallet-ledger", async () => {
    const users = await store.users();
    const u = users.find((x) => x.id === uid);
    if (!u) return null;
    const balance = Number(u.balance) || 0;
    const newBal = Math.round((balance + amount) * 100) / 100;
    u.balance = newBal;
    u.updatedAt = new Date().toISOString();
    await store.writeUsers(users);

    // Safe sync to Supabase (clamps 32-bit int & protects against deletion)
    await store.syncUserRowToSupabase(u);
    return u;
  });
}
async function setStatusLocked(topupId, patch) {
  const l = await topups();
  const t = l.find((x) => x.id === topupId);
  if (t) Object.assign(t, patch, { updatedAt: new Date().toISOString() });
  await store.writeTopups(l);
  return t;
}
async function setStatus(topupId, patch) {
  return store.withLock("topups-ledger", () => setStatusLocked(topupId, patch));
}

router.get("/config", (req, res) => {
  const s = store.settingsSync ? store.settingsSync() : {};
  res.json({
    demo: DEMO,
    truemoney: DEMO || Boolean(process.env.TRUEMONEY_PHONE || s.truemoney_phone),
    promptpay: true,
  });
});

router.get("/topups", asyncRoute(async (req, res) => {
  const list = (await topups()).filter((t) => t.uid === req.user.id).slice(-20).reverse()
    .map((t) => ({ id: t.id, method: t.method, amount: t.amount, status: t.status, createdAt: t.createdAt, expiresAt: t.expiresAt }));
  res.json({ balance: Number(req.user.balance) || 0, topups: list });
}));

router.post("/truemoney", (req, res, next) => {
  const s = store.settingsSync ? store.settingsSync() : {};
  if ((s.topup_mode === "disabled" || s.maintenance) && (!req.user || req.user.role !== "admin")) {
    return err(res, 503, "topup_disabled", "ระบบเติมเงินกำลังปิดปรับปรุงชั่วคราว");
  }
  const code = tm.parseVoucher((req.body || {}).link);
  if (!code) return err(res, 400, "bad_link", "ลิงก์อั่งเปาไม่ถูกต้อง");

  store.withLock("voucher:" + code, async () => {
    // --- dedup: เช็คใน Supabase ก่อน (ถ้าเชื่อมอยู่) ---
    const dbClient = require("../lib/db").getClient();
    if (dbClient) {
      const { data: dup } = await dbClient
        .from("topups")
        .select("id, status")
        .eq("voucher_code", code)
        .in("status", ["approved", "processing"])
        .maybeSingle();
      if (dup) return err(res, 409, "already_used", "ซองอั่งเปานี้ถูกใช้ไปแล้ว");
    }

    const rec = await store.withLock("topups-ledger", async () => {
      const list = await topups();
      if (list.some((t) => t.method === "truemoney" && t.ref === code && t.status !== "rejected")) return null;
      const pending = {
        id: id("T"), uid: req.user.id, method: "truemoney",
        amount: 0, status: "processing", ref: code,
        voucher_code: code,
        createdAt: new Date().toISOString(),
      };
      list.push(pending);
      await store.writeTopups(list);
      return pending;
    });
    if (!rec) return err(res, 409, "already_used", "ซองอั่งเปานี้ถูกใช้ไปแล้ว");

    let baht;
    try {
      baht = await tm.redeem(code, DEMO, s.truemoney_phone || process.env.TRUEMONEY_PHONE);
    } catch (e) {
      if (e.code === "network") {
        return err(res, 503, "verification_pending",
          "ยังตรวจสอบผลซองไม่ได้ รายการถูกพักไว้ กรุณาติดต่อทีมงานพร้อมรหัส " + rec.id);
      }
      await setStatus(rec.id, { status: "rejected", note: e.code });
      return err(res, e.status || 502, e.code || "redeem_failed", e.message);
    }

    try {
      const u = await credit(req.user.id, baht);
      if (!u) throw new Error("user_not_found_after_redemption");
      await setStatus(rec.id, { amount: baht, status: "approved" });
      res.json({ ok: true, amount: baht, balance: Number(u.balance) || 0 });
    } catch (e) {
      console.error("[wallet] TrueMoney reconciliation needed:", rec.id, e.message || e);
      err(res, 503, "credit_pending",
        "แลกซองสำเร็จ แต่ยืนยันยอดในระบบไม่ครบ กรุณาติดต่อทีมงานพร้อมรหัส " + rec.id);
    }
  }).catch(next);
});

router.post("/promptpay", (req, res, next) => {
  const s = store.settingsSync ? store.settingsSync() : {};
  if ((s.topup_mode === "disabled" || s.maintenance) && (!req.user || req.user.role !== "admin")) {
    return err(res, 503, "topup_disabled", "ระบบเติมเงินกำลังปิดปรับปรุงชั่วคราว");
  }
  const target = process.env.PROMPTPAY_ID || s.promptpay_id || "0812345678";
  const baht = Math.floor(Number((req.body || {}).amount));
  if (!Number.isFinite(baht) || baht < 1 || baht > 100000) return err(res, 400, "bad_amount", "เติมเงินขั้นต่ำ 1 สูงสุด 100,000 บาท");
  store.withLock("topups-ledger", async () => {
  const list = await topups();
  const now = Date.now();
  list.forEach((t) => { if (t.uid === req.user.id && t.method === "promptpay" && t.status === "pending") t.status = "cancelled"; });
  const used = new Set(list.filter((t) => t.method === "promptpay" && t.status === "pending" && t.expiresAt > now).map((t) => t.amount));
  // add a small cent offset (0.01–0.99) to make each QR uniquely identifiable
  let amount = 0;
  for (let c = 1; c <= 99; c++) {
    const candidate = Math.round((baht + c / 100) * 100) / 100;
    if (!used.has(candidate)) { amount = candidate; break; }
  }
  if (!amount) return err(res, 503, "busy", "มีรายการรอชำระมากเกินไป ลองใหม่อีกครั้ง");
  const qrExpireMs = 15 * 60 * 1000; // 15 minutes matching inficoz (14:59)
  const rec = { id: id("P"), uid: req.user.id, method: "promptpay", amount, baseAmount: baht, status: "pending", createdAt: new Date(now).toISOString(), expiresAt: now + qrExpireMs };
  const data = pp.payload(target, amount);
  const qr = QR ? ("/api/wallet/promptpay/" + rec.id + "/qr.png") : null;
  list.push(rec);
  await store.writeTopups(list);
  res.status(201).json({ id: rec.id, amount, baseAmount: baht, payload: data, qr, expiresAt: rec.expiresAt });
  }).catch(next);
});

router.get("/promptpay/:id/qr.png", asyncRoute(async (req, res) => {
  if (!QR) return err(res, 404, "not_found", "QR generator unavailable");
  const t = (await topups()).find((x) => x.id === req.params.id && x.uid === req.user.id);
  if (!t) return err(res, 404, "not_found", "ไม่พบรายการ");
  const s = store.settings ? await store.settings() : {};
  const target = process.env.PROMPTPAY_ID || s.promptpay_id || "0812345678";
  const data = pp.payload(target, t.amount);
  const buf = await QR.toBuffer(data, { margin: 1, width: 320 });
  res.type("image/png").send(buf);
}));

router.post("/promptpay/:id/cancel", (req, res, next) => {
  store.withLock("topups-ledger", async () => {
  const t = (await topups()).find((x) => x.id === req.params.id && x.uid === req.user.id && x.status === "pending");
  if (!t) return err(res, 404, "not_found", "ไม่พบรายการ");
    await setStatusLocked(t.id, { status: "cancelled" });
  res.json({ ok: true });
  }).catch(next);
});

// demo only: pretend the bank transfer arrived
router.post("/promptpay/:id/simulate", (req, res, next) => {
  if (!DEMO) return err(res, 404, "not_found", "ไม่พบ");
  store.withLock("topups-ledger", async () => {
  const t = (await topups()).find((x) => x.id === req.params.id && x.uid === req.user.id && x.status === "pending");
  if (!t) return err(res, 404, "not_found", "ไม่พบรายการ");
  await setStatusLocked(t.id, { status: "processing" });
  const balance = await credit(req.user.id, t.amount);
  await setStatusLocked(t.id, { status: "approved" });
  res.json({ ok: true, balance: Number(balance.balance) || 0 });
  }).catch(next);
});

module.exports = router;
module.exports.credit = credit;
module.exports.setStatus = setStatus;
module.exports.setStatusLocked = setStatusLocked;
