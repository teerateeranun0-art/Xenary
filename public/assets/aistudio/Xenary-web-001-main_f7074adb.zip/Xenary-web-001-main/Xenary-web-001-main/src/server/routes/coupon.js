// POST /api/coupon/redeem  { code }  – redeem a coupon (auth required)
const express = require("express");
const asyncRoute = require("../lib/async-route");
const auth = require("../lib/auth");
const store = require("../lib/store");
const wallet = require("./wallet");

const router = express.Router();
router.use(auth.requireAuth);

router.post("/redeem", asyncRoute(async (req, res) => {
  const s = store.settings ? await store.settings() : {};
  if ((s.topup_mode === "disabled" || s.maintenance) && (!req.user || req.user.role !== "admin")) {
    return res.status(503).json({ error: "topup_disabled", message: "ระบบแลกคูปองกำลังปิดปรับปรุงชั่วคราว" });
  }
  const code = String((req.body || {}).code || "").trim().toUpperCase();
  if (!code || code.length > 64) {
    return res.status(400).json({ error: "bad_code", message: "กรุณากรอกรหัสคูปองที่ถูกต้อง" });
  }

  return store.withLock("coupon-redeem", async () => {
    const coupons = await store.coupons();
    const idx = coupons.findIndex((c) => c.code === code);
    if (idx === -1) {
      return res.status(404).json({ error: "not_found", message: "ไม่พบรหัสคูปองนี้ในระบบ" });
    }

    const cp = coupons[idx];
    if (!cp.enabled) {
      return res.status(400).json({ error: "disabled", message: "คูปองนี้ถูกปิดการใช้งานแล้ว" });
    }
    if (cp.expires_at && new Date(cp.expires_at).getTime() < Date.now()) {
      return res.status(400).json({ error: "expired", message: "คูปองนี้หมดอายุแล้ว" });
    }
    if (cp.max_uses != null && Number(cp.used_count || 0) >= Number(cp.max_uses)) {
      return res.status(400).json({ error: "exhausted", message: "คูปองนี้ถูกใช้งานครบตามจำนวนสิทธิ์แล้ว" });
    }

    const uses = await store.couponUses();
    const userUses = (uses || []).filter((u) => u.coupon_id === cp.id && u.user_id === req.user.id).length;
    const perLimit = Number(cp.per_user_limit) || 1;
    if (userUses >= perLimit) {
      return res.status(400).json({ error: "already_used", message: "คุณเคยใช้คูปองนี้ครบสิทธิ์ไปแล้ว" });
    }

    const amount = Number(cp.amount) || 0;
    const updatedUser = await wallet.credit(req.user.id, amount);
    if (!updatedUser) {
      return res.status(404).json({ error: "user_not_found", message: "ไม่พบบัญชีผู้ใช้" });
    }

    cp.used_count = Number(cp.used_count || 0) + 1;
    await store.writeCoupons(coupons);

    uses.push({
      id: "cu_" + Date.now().toString(36),
      coupon_id: cp.id,
      code: cp.code,
      user_id: req.user.id,
      amount,
      used_at: new Date().toISOString(),
    });
    await store.writeCouponUses(uses);

    res.json({
      ok: true,
      amount,
      balance: updatedUser.balance,
      message: "แลกคูปองสำเร็จ! ได้รับเครดิต ฿" + amount.toFixed(2),
    });
  });
}));

module.exports = router;
