const crypto = require("node:crypto");
const express = require("express");
const store = require("../lib/store");
const auth = require("../lib/auth");
const wallet = require("./wallet");
const asyncRoute = require("../lib/async-route");
const db = require("../lib/db");

const router = express.Router();
router.use(auth.requireAdmin);

// ---- helpers ----
const name = async (uid) => ((await store.users()).find((u) => u.id === uid) || {}).username || uid;
const bad = (res, status, error, message) => res.status(status).json({ error, message });
const genId = (prefix) => prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const safeUrl = (u, allowDataImage = false) => {
  const s = String(u || "").trim();
  if (!s) return "";
  if (allowDataImage && /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(s)) return s;
  if (/^(https?:\/\/|mailto:|tel:|\/|#)/i.test(s)) return s;
  return "";
};

// ================================================================
// 1. DASHBOARD STATS (Real-time accurate computation)
// ================================================================
router.get("/stats", asyncRoute(async (req, res) => {
  const [orders, users, topups, cat] = await Promise.all([
    store.orders(),
    store.users(),
    store.topups(),
    store.catalog(),
  ]);
  const manualTops = await store.manualTopups();
  const allKeys = await store.keys();

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const monthStr = now.toISOString().slice(0, 7);

  const paidOrders = (orders || []).filter((o) =>
    ["paid", "delivered", "completed"].includes(o.status)
  );

  let revToday = 0;
  let revMonth = 0;
  let revTotal = 0;

  paidOrders.forEach((o) => {
    const amt = Number(o.total) || 0;
    revTotal += amt;
    const dt = String(o.paidAt || o.createdAt || "");
    if (dt.startsWith(todayStr)) revToday += amt;
    if (dt.startsWith(monthStr)) revMonth += amt;
  });

  const pendingPp = (topups || []).filter(
    (t) => t.status === "pending" || t.status === "processing"
  ).length;
  const pendingManual = (manualTops || []).filter((t) => t.status === "pending").length;
  const unusedKeys = (allKeys || []).filter((k) => !k.is_used).length;

  res.json({
    revenue_today: revToday,
    revenue_month: revMonth,
    revenue_total: revTotal,
    paid_orders_count: paidOrders.length,
    total_users: (users || []).length,
    pending_topups_count: pendingPp + pendingManual,
    unused_keys_count: unusedKeys,
    products_count: (cat.products || []).length,
  });
}));

// ================================================================
// 2. PRODUCTS MANAGEMENT (Create, Edit/Update, Delete)
// ================================================================
router.get("/products", asyncRoute(async (req, res) => {
  const cat = await store.catalog();
  const allKeys = await store.keys();
  const products = (cat.products || []).map((p) => {
    const keyCount = allKeys.filter((k) => k.product_id === p.slug && !k.is_used).length;
    return { ...p, unused_keys: keyCount };
  });
  res.json({ products });
}));

async function buildProductPayload(b, existing) {
  const name_ = String(b.name ?? existing?.name ?? "").trim().slice(0, 120);
  let slug = String(b.slug ?? existing?.slug ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  if (!slug && name_) {
    slug = name_
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "");
  }
  if (!slug) slug = "prod-" + Date.now().toString(36);

  const tag = String(b.tag ?? existing?.tag ?? "Valorant").trim().slice(0, 50) || "General";
  const desc = String(b.desc ?? existing?.desc ?? "").trim().slice(0, 1000);
  const rawDl = String(b.download_url ?? b.downloadUrl ?? existing?.download_url ?? "").trim().slice(0, 500);
  const downloadUrl = /^(https?:\/\/|\/)/i.test(rawDl) ? rawDl : "";
  const rawImg = String(b.img ?? existing?.img ?? "").trim().slice(0, 500);
  const img = (/^(https?:\/\/|\/|data:image\/)/i.test(rawImg) ? rawImg : "") ||
    "https://img2.pic.in.th/serifaimcolor3.png";

  const allKeys = await store.keys();
  const unusedKeyCount = allKeys.filter((k) => k.product_id === slug && !k.is_used).length;
  const sold = Number.isFinite(Number(b.sold))
    ? Math.max(0, Math.floor(Number(b.sold)))
    : (existing?.sold ?? 0);
  const bestSeller = b.bestSeller !== undefined ? Boolean(b.bestSeller) : Boolean(existing?.bestSeller);
  const featured = b.featured !== undefined ? Boolean(b.featured) : (existing?.featured !== false);
  const updating = b.updating !== undefined
    ? Boolean(b.updating)
    : (b.status_mode !== undefined ? b.status_mode === "updating" : Boolean(existing?.updating || existing?.status_mode === "updating"));
  const updateNote = String(b.update_note ?? existing?.update_note ?? "").trim().slice(0, 200);

  let plans = [];
  if (Array.isArray(b.plans) && b.plans.length) {
    plans = b.plans
      .map((p) => {
        const label = String(p.label || "").trim();
        const price = Number(p.price);
        const per = String(p.per || ("/" + label)).trim();
        return { label, price, per };
      })
      .filter((p) => p.label && Number.isFinite(p.price) && p.price > 0);
  }

  if (!plans.length) {
    const fallbackPrice = Number(b.price);
    if (Number.isFinite(fallbackPrice) && fallbackPrice > 0) {
      plans = [{ label: "มาตรฐาน", price: fallbackPrice, per: "/ชิ้น" }];
    } else if (existing?.plans?.length) {
      plans = existing.plans;
    }
  }

  return {
    slug,
    id: slug,
    channel: slug,
    name: name_,
    tag,
    desc,
    download_url: downloadUrl,
    stock: unusedKeyCount,
    sold,
    bestSeller,
    featured,
    updating,
    status_mode: updating ? "updating" : "normal",
    update_note: updateNote,
    updatedAt: new Date().toISOString(),
    key_based: true,
    img,
    plans,
  };
}

router.post("/products", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const b = req.body || {};
    if (!String(b.name || "").trim()) {
      return bad(res, 400, "missing_name", "กรุณาระบุชื่อสินค้า");
    }
    const product = await buildProductPayload(b, null);
    if (!product.plans.length) {
      return bad(res, 400, "invalid_plans", "กรุณาระบุราคาสินค้าอย่างน้อย 1 แพ็กเกจ (ราคาต้องมากกว่า 0 บาท)");
    }
    await store.saveProduct(product, b.originalSlug || product.slug);
    if (product.key_based) store.syncProductKeyStock(product.slug);
    return res.status(201).json({ ok: true, product });
  });
}));

router.put("/products/:slug", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const targetSlug = String(req.params.slug || "").trim();
    const cat = await store.catalog();
    const existing = (cat.products || []).find((p) => p.slug === targetSlug || p.id === targetSlug);
    if (!existing) {
      return bad(res, 404, "not_found", "ไม่พบสินค้าที่ต้องการแก้ไข");
    }
    const b = req.body || {};
    const product = await buildProductPayload(b, existing);
    if (!product.name) {
      return bad(res, 400, "missing_name", "กรุณาระบุชื่อสินค้า");
    }
    if (!product.plans.length) {
      return bad(res, 400, "invalid_plans", "กรุณาระบุราคาสินค้าอย่างน้อย 1 แพ็กเกจ (ราคาต้องมากกว่า 0 บาท)");
    }
    await store.saveProduct(product, targetSlug);
    if (product.key_based) store.syncProductKeyStock(product.slug);
    return res.json({ ok: true, product });
  });
}));

router.delete("/products/:slug", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const slug = String(req.params.slug || "").trim();
    await store.deleteProduct(slug);
    return res.json({ ok: true });
  });
}));

router.post("/products/:slug/toggle-update", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const targetSlug = String(req.params.slug || "").trim();
    const cat = await store.catalog();
    const existing = (cat.products || []).find((p) => p.slug === targetSlug || p.id === targetSlug);
    if (!existing) {
      return bad(res, 404, "not_found", "ไม่พบสินค้านี้ในระบบ");
    }
    const b = req.body || {};
    const nextUpdating = b.updating !== undefined ? Boolean(b.updating) : !existing.updating;
    const updateNote = b.update_note !== undefined ? String(b.update_note).trim().slice(0, 200) : (existing.update_note || "");
    const updatedProd = {
      ...existing,
      updating: nextUpdating,
      status_mode: nextUpdating ? "updating" : "normal",
      update_note: updateNote,
      updatedAt: new Date().toISOString(),
    };
    await store.saveProduct(updatedProd, targetSlug);
    return res.json({ ok: true, product: updatedProd });
  });
}));

// ================================================================
// 3. TOPUPS (PromptPay & Manual Bank Slip)
// ================================================================
router.get("/topups", asyncRoute(async (req, res) => {
  const status = req.query.status || "pending";
  const all = await store.topups();
  const list = await Promise.all(
    (all || [])
      .filter((t) =>
        status === "all"
          ? true
          : status === "pending"
            ? t.status === "pending" || t.status === "processing"
            : t.status === status
      )
      .reverse()
      .slice(0, 100)
      .map(async (t) => ({ ...t, user: await name(t.uid) }))
  );
  res.json({ topups: list });
}));

router.post("/topups/:id/:action(approve|reject)", (req, res, next) => {
  store.withLock("topups-ledger", async () => {
    const t = (await store.topups()).find((x) => x.id === req.params.id);
    if (!t || (t.status !== "pending" && t.status !== "processing")) {
      return res.status(404).json({ error: "not_found", message: "ไม่พบรายการหรือดำเนินการไปแล้ว" });
    }
    if (req.params.action === "reject") {
      await wallet.setStatusLocked(t.id, { status: "rejected" });
      return res.json({ ok: true });
    }
    await wallet.setStatusLocked(t.id, { status: "approved" });
    const user = await wallet.credit(t.uid, Number(t.amount) || 0);
    if (!user) {
      await wallet.setStatusLocked(t.id, { status: "pending" });
      return bad(res, 404, "user_not_found", "ไม่พบบัญชีผู้ใช้ของรายการนี้");
    }
    return res.json({ ok: true, new_balance: user.balance });
  }).catch(next);
});

router.get("/manual-topups", asyncRoute(async (req, res) => {
  const status = req.query.status || "pending";
  const localList = await store.manualTopups();
  const channels = await store.paymentChannels();
  const usersList = await store.users();

  const enriched = localList
    .filter((t) => (status === "all" ? true : t.status === status))
    .reverse()
    .slice(0, 100)
    .map((t) => {
      const u = usersList.find((x) => x.id === t.user_id);
      const ch = channels.find((x) => String(x.id) === String(t.channel_id));
      return {
        ...t,
        username: u ? u.username : (t.username || t.user_id),
        channel_name: ch ? ch.name : (t.channel_name || "โอนผ่านบัญชีธนาคาร"),
      };
    });

  res.json({ topups: enriched });
}));

router.post("/manual-topups/:id/:action(approve|reject)", asyncRoute(async (req, res) => {
  return store.withLock("manual-topups-ledger", async () => {
    const { id, action } = req.params;
    const note = String((req.body || {}).note || "").trim().slice(0, 500) || null;
    const list = await store.manualTopups();
    const idx = list.findIndex((x) => String(x.id) === String(id));
    if (idx === -1) {
      return bad(res, 404, "not_found", "ไม่พบรายการแจ้งโอนเงิน");
    }
    const item = list[idx];
    if (item.status !== "pending") {
      return bad(res, 400, "already_processed", "รายการนี้ถูกดำเนินการไปแล้ว");
    }

    if (action === "reject") {
      item.status = "rejected";
      item.admin_note = note;
      item.updated_at = new Date().toISOString();
      await store.writeManualTopups(list);
      return res.json({ ok: true });
    }

    // Approve and credit user balance atomically
    const user = await wallet.credit(item.user_id, Number(item.amount) || 0);
    if (!user) {
      return bad(res, 404, "user_not_found", "ไม่พบบัญชีผู้ใช้สำหรับเติมเงิน");
    }
    item.status = "approved";
    item.admin_note = note;
    item.approved_at = new Date().toISOString();
    item.updated_at = item.approved_at;
    await store.writeManualTopups(list);
    return res.json({ ok: true, new_balance: user.balance });
  });
}));

// ================================================================
// 4. ORDERS
// ================================================================
router.get("/orders", asyncRoute(async (req, res) => {
  const orders = await store.orders();
  const list = await Promise.all(
    (orders || [])
      .slice(-100)
      .reverse()
      .map(async (o) => ({
        ...o,
        user: o.userId ? await name(o.userId) : (o.buyer || "Guest"),
      }))
  );
  res.json({ orders: list });
}));

router.patch("/orders/:id", asyncRoute(async (req, res) => {
  const status = (req.body || {}).status;
  if (status === "cancelled" || status === "refunded") {
    return bad(res, 403, "cancel_disabled", "คำสั่งซื้อที่ส่งมอบสินค้าแล้วไม่สามารถยกเลิกหรือคืนเงินได้");
  }
  if (!["paid", "delivered", "completed"].includes(status)) {
    return bad(res, 400, "bad_status", "สถานะไม่ถูกต้อง");
  }
  const orders = await store.orders();
  const existing = orders.find((o) => o.id === req.params.id);
  if (!existing) return bad(res, 404, "order_not_found", "ไม่พบคำสั่งซื้อ");

  const updated = await store.updateOrder(req.params.id, { status });
  res.json(updated || { ok: true });
}));

// ================================================================
// 5. PRODUCT KEYS (Local JSON + Grouped by Product + Auto Sync Stock)
// ================================================================
router.get("/keys", asyncRoute(async (req, res) => {
  const allKeys = await store.keys();
  const cat = await store.catalog();
  const products = cat.products || [];
  const prodObjMap = new Map();
  products.forEach((p) => {
    prodObjMap.set(p.slug, p);
    if (p.id) prodObjMap.set(p.id, p);
  });

  let filtered = allKeys;
  if (req.query.product_id) {
    filtered = filtered.filter((k) => k.product_id === req.query.product_id);
  }
  if (req.query.plan_label !== undefined && req.query.plan_label !== "") {
    if (req.query.plan_label === "__any__") {
      filtered = filtered.filter((k) => !k.plan_label);
    } else {
      filtered = filtered.filter((k) => String(k.plan_label || "") === String(req.query.plan_label));
    }
  }
  if (req.query.unused === "1" || req.query.status === "unused") {
    filtered = filtered.filter((k) => !k.is_used);
  } else if (req.query.status === "used") {
    filtered = filtered.filter((k) => Boolean(k.is_used));
  }
  if (req.query.q) {
    const q = String(req.query.q).trim().toLowerCase();
    if (q) {
      filtered = filtered.filter((k) =>
        String(k.key_value || "").toLowerCase().includes(q) ||
        String(k.order_id || "").toLowerCase().includes(q) ||
        String(k.plan_label || "").toLowerCase().includes(q) ||
        String(k.product_id || "").toLowerCase().includes(q)
      );
    }
  }

  const out = filtered
    .slice(-1000)
    .reverse()
    .map((k) => {
      const p = prodObjMap.get(k.product_id);
      return {
        ...k,
        product_name: p ? p.name : k.product_id,
        product_tag: p ? (p.tag || "General") : "General",
        product_img: p ? (p.img || "") : "",
      };
    });

  res.json({ keys: out });
}));

router.post("/keys", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const productId = String((req.body || {}).product_id || "").trim();
    const planLabel = String((req.body || {}).plan_label || "").trim() || null;
    const rawKeys = (req.body || {}).keys;
    const syncStock = (req.body || {}).sync_stock !== false;

    if (!productId) return bad(res, 400, "missing_product", "กรุณาเลือกสินค้าที่ต้องการเพิ่มคีย์");
    if (!Array.isArray(rawKeys) || rawKeys.length === 0) {
      return bad(res, 400, "missing_keys", "กรุณากรอกคีย์อย่างน้อย 1 รายการ");
    }

    const cleanKeys = Array.from(new Set(rawKeys.map((k) => String(k || "").trim()).filter(Boolean)));
    if (!cleanKeys.length) return bad(res, 400, "empty_keys", "ไม่มีคีย์ที่ถูกต้อง");

    const allKeys = await store.keys();
    const existingUnusedSet = new Set(
      allKeys.filter((k) => k.product_id === productId && !k.is_used).map((k) => k.key_value)
    );
    const uniqueNewKeys = cleanKeys.filter((kv) => !existingUnusedSet.has(kv));
    if (!uniqueNewKeys.length) {
      return bad(res, 409, "duplicate_keys", "คีย์ที่ระบุมีอยู่ในคลังพร้อมขายของสินค้านี้อยู่แล้วทั้งหมด");
    }

    const now = new Date().toISOString();
    const addedRows = uniqueNewKeys.map((kv) => ({
      id: genId("key"),
      product_id: productId,
      plan_label: planLabel,
      key_value: kv,
      is_used: false,
      order_id: null,
      created_at: now,
    }));

    allKeys.push(...addedRows);
    await store.writeKeys(allKeys);

    // Update product stock & mark key_based if requested
    if (syncStock) {
      await store.syncProductKeyStock(productId);
    }

    return res.status(201).json({
      ok: true,
      added: addedRows.length,
      skipped_duplicates: cleanKeys.length - uniqueNewKeys.length,
    });
  });
}));

router.patch("/keys/:id", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const id = String(req.params.id || "");
    const allKeys = await store.keys();
    const idx = allKeys.findIndex((k) => String(k.id) === id);
    if (idx === -1) return bad(res, 404, "not_found", "ไม่พบคีย์ที่ต้องการแก้ไข");

    const b = req.body || {};
    const oldProdId = allKeys[idx].product_id;

    if (b.key_value !== undefined) {
      const kv = String(b.key_value || "").trim();
      if (!kv) return bad(res, 400, "empty_key", "รหัสคีย์ห้ามว่างเปล่า");
      allKeys[idx].key_value = kv;
    }
    if (b.plan_label !== undefined) {
      allKeys[idx].plan_label = String(b.plan_label || "").trim() || null;
    }
    if (b.product_id !== undefined && String(b.product_id).trim()) {
      allKeys[idx].product_id = String(b.product_id).trim();
    }
    if (b.is_used !== undefined) {
      allKeys[idx].is_used = Boolean(b.is_used);
    }
    allKeys[idx].updated_at = new Date().toISOString();

    await store.writeKeys(allKeys);
    if (oldProdId) store.syncProductKeyStock(oldProdId);
    if (allKeys[idx].product_id && allKeys[idx].product_id !== oldProdId) {
      store.syncProductKeyStock(allKeys[idx].product_id);
    }

    return res.json({ ok: true, key: allKeys[idx] });
  });
}));

router.delete("/keys/bulk/used", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const productId = String(req.query.product_id || (req.body || {}).product_id || "").trim();
    const allKeys = await store.keys();
    const beforeCount = allKeys.length;
    const affectedProds = new Set();

    const nextKeys = allKeys.filter((k) => {
      if (!k.is_used) return true;
      if (productId && k.product_id !== productId) return true;
      if (k.product_id) affectedProds.add(k.product_id);
      return false;
    });

    await store.writeKeys(nextKeys);
    affectedProds.forEach((pid) => store.syncProductKeyStock(pid));

    return res.json({ ok: true, removed: beforeCount - nextKeys.length });
  });
}));

router.delete("/keys/:id", asyncRoute(async (req, res) => {
  return store.withLock("wallet-ledger", async () => {
    const id = String(req.params.id || "");
    const allKeys = await store.keys();
    const target = allKeys.find((k) => String(k.id) === id);
    const nextKeys = allKeys.filter((k) => String(k.id) !== id);
    await store.writeKeys(nextKeys);

    if (target && target.product_id) {
      store.syncProductKeyStock(target.product_id);
    }
    return res.json({ ok: true });
  });
}));

// ================================================================
// 6. USER MANAGEMENT & BALANCE ADJUSTMENT
// ================================================================
router.get("/users", asyncRoute(async (req, res) => {
  const users = await store.users();
  res.json({
    users: (users || []).map((u) => ({
      id: u.id,
      username: u.username,
      balance: Number(u.balance) || 0,
      role: u.role || "user",
      banned: Boolean(u.banned),
      createdAt: u.createdAt || u.created_at,
    })),
  });
}));

router.patch("/users/:id", asyncRoute(async (req, res) => {
  const b = req.body || {};
  const patch = {};
  if (b.banned !== undefined) patch.banned = Boolean(b.banned);
  if (b.ban_reason !== undefined) patch.ban_reason = String(b.ban_reason).slice(0, 200) || null;
  if (b.role !== undefined && ["user", "admin", "moderator"].includes(b.role)) patch.role = b.role;
  if (!Object.keys(patch).length) return bad(res, 400, "no_fields", "ไม่มีข้อมูลที่จะอัปเดต");

  // Prevent admin from banning or demoting their own currently logged-in account
  if (req.user && String(req.user.id) === String(req.params.id)) {
    if (patch.banned === true) {
      return bad(res, 400, "cannot_ban_self", "ไม่สามารถระงับบัญชีแอดมินของตัวเองได้");
    }
    if (patch.role && patch.role !== "admin") {
      return bad(res, 400, "cannot_demote_self", "ไม่สามารถลดสิทธิ์แอดมินของตัวเองได้");
    }
  }

  return store.withLock("wallet-ledger", async () => {
    // 1. Update local users.json atomically
    const users = await store.users();
    const idx = users.findIndex((u) => String(u.id) === String(req.params.id));
    if (idx === -1) return bad(res, 404, "user_not_found", "ไม่พบบัญชีผู้ใช้");
    users[idx] = { ...users[idx], ...patch, updatedAt: new Date().toISOString() };
    await store.writeUsers(users);

    // 2. If user is banned, immediately revoke all active sessions for that user
    if (patch.banned === true) {
      await store.withLock("sessions-ledger", async () => {
        const sessions = await store.sessions();
        const remaining = (sessions || []).filter((s) => String(s.uid) !== String(req.params.id));
        if (remaining.length !== (sessions || []).length) {
          await store.writeSessions(remaining);
        }
      });
    }

    // 3. Safe Sync to Supabase (with integer clamping & rollback protection)
    await store.syncUserRowToSupabase(users[idx]);

    return res.json({ ok: true, user: users[idx] });
  });
}));

router.post("/users/:id/adjust-balance", asyncRoute(async (req, res) => {
  const b = req.body || {};
  const hasSetBalance = b.set_balance !== undefined && b.set_balance !== null && b.set_balance !== "";
  const setBalVal = hasSetBalance ? Number(b.set_balance) : null;
  const amount = Number(b.amount);

  if (!hasSetBalance && (!Number.isFinite(amount) || amount === 0)) {
    return bad(res, 400, "bad_amount", "กรุณาระบุจำนวนเงิน (บวก=เพิ่ม, ลบ=หัก)");
  }
  if (hasSetBalance && (!Number.isFinite(setBalVal) || setBalVal < 0)) {
    return bad(res, 400, "bad_amount", "ยอดเงินคงเหลือต้องเป็นตัวเลขตั้งแต่ 0 ขึ้นไป");
  }

  return store.withLock("wallet-ledger", async () => {
    const users = await store.users();
    const idx = users.findIndex((u) => String(u.id) === String(req.params.id));
    if (idx === -1) return bad(res, 404, "user_not_found", "ไม่พบผู้ใช้ในระบบ");

    const currentBal = Number(users[idx].balance) || 0;
    const rawNewBal = hasSetBalance ? setBalVal : (currentBal + amount);
    if (!Number.isFinite(rawNewBal) || rawNewBal > 999999999999) {
      return bad(res, 400, "max_balance_exceeded", "ยอดเงินเกินขีดจำกัดสูงสุดของระบบ (สูงสุด 999,999,999,999 บาท)");
    }
    const newBal = Math.round(rawNewBal * 100) / 100;
    if (newBal < 0) {
      return bad(res, 400, "insufficient_balance", "ยอดเงินไม่พอให้หัก (ยอดปัจจุบัน: ฿" + currentBal + ")");
    }

    users[idx].balance = newBal;
    users[idx].updatedAt = new Date().toISOString();
    await store.writeUsers(users);

    // Safe Sync with Supabase (clamps 32-bit int & rolls back on error so user is NEVER deleted)
    const sync = await store.syncUserRowToSupabase(users[idx]);
    if (sync && sync.ok === false) {
      users[idx].balance = currentBal;
      await store.writeUsers(users);
      const why = (sync.error && (sync.error.message || sync.error.code)) || "unknown";
      return bad(res, 502, "db_write_failed", "บันทึกยอดเงินลงฐานข้อมูลไม่สำเร็จ: " + why + " (ตรวจ SUPABASE_SERVICE_ROLE_KEY / สิทธิ์ตาราง users)");
    }

    return res.json({ ok: true, new_balance: newBal });
  });
}));

// ================================================================
// 7. COUPONS (Local Store)
// ================================================================
router.get("/coupons", asyncRoute(async (req, res) => {
  const list = await store.coupons();
  res.json({ coupons: list.slice().reverse() });
}));

router.post("/coupons", asyncRoute(async (req, res) => {
  return store.withLock("coupon-redeem", async () => {
    const b = req.body || {};
    const code = String(b.code || "").trim().toUpperCase();
    const amount = Number(b.amount);
    const maxUses = b.max_uses != null && b.max_uses !== "" ? Number(b.max_uses) : null;
    const perUserLimit = Number(b.per_user_limit) || 1;
    const note = String(b.note || "").trim().slice(0, 200) || null;

    if (!code || code.length > 64) return bad(res, 400, "bad_code", "รหัสคูปองต้องมี 1–64 ตัวอักษร");
    if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000) return bad(res, 400, "bad_amount", "มูลค่าเครดิตต้องอยู่ระหว่าง 1 ถึง 1,000,000 บาท");

    const list = await store.coupons();
    if (list.some((c) => c.code === code)) {
      return bad(res, 409, "duplicate_code", "รหัสคูปองนี้มีอยู่ในระบบแล้ว");
    }

    const newCoupon = {
      id: genId("cp"),
      code,
      amount,
      max_uses: maxUses,
      used_count: 0,
      per_user_limit: perUserLimit,
      note,
      enabled: true,
      created_at: new Date().toISOString(),
    };

    list.push(newCoupon);
    await store.writeCoupons(list);
    return res.status(201).json({ ok: true, id: newCoupon.id, coupon: newCoupon });
  });
}));

router.patch("/coupons/:id", asyncRoute(async (req, res) => {
  return store.withLock("coupon-redeem", async () => {
    const list = await store.coupons();
    const idx = list.findIndex((c) => String(c.id) === String(req.params.id));
    if (idx === -1) return bad(res, 404, "not_found", "ไม่พบคูปอง");

    const b = req.body || {};
    if (b.code !== undefined) {
      const cleanCode = String(b.code || "").trim().toUpperCase();
      if (!cleanCode || cleanCode.length > 64) return bad(res, 400, "bad_code", "รหัสคูปองต้องมี 1–64 ตัวอักษร");
      if (list.some((c, i) => i !== idx && c.code === cleanCode)) {
        return bad(res, 409, "duplicate_code", "รหัสคูปองนี้มีอยู่ในระบบแล้ว");
      }
      list[idx].code = cleanCode;
    }
    if (b.amount !== undefined) {
      const amt = Number(b.amount);
      if (!Number.isFinite(amt) || amt <= 0 || amt > 1000000) return bad(res, 400, "bad_amount", "มูลค่าเครดิตต้องอยู่ระหว่าง 1 ถึง 1,000,000 บาท");
      list[idx].amount = amt;
    }
    if (b.enabled !== undefined) list[idx].enabled = Boolean(b.enabled);
    if (b.note !== undefined) list[idx].note = String(b.note).slice(0, 200);
    if (b.max_uses !== undefined) list[idx].max_uses = b.max_uses != null && b.max_uses !== "" ? Number(b.max_uses) : null;

    await store.writeCoupons(list);
    return res.json({ ok: true, coupon: list[idx] });
  });
}));

router.delete("/coupons/:id", asyncRoute(async (req, res) => {
  return store.withLock("coupon-redeem", async () => {
    const list = (await store.coupons()).filter((c) => String(c.id) !== String(req.params.id));
    await store.writeCoupons(list);
    return res.json({ ok: true });
  });
}));

// ================================================================
// 8. NEWS / ANNOUNCEMENTS (Local Store)
// ================================================================
router.get("/news", asyncRoute(async (req, res) => {
  const list = await store.news();
  res.json({ posts: list.slice().reverse() });
}));

router.post("/news", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const b = req.body || {};
    const title = String(b.title || "").trim().slice(0, 200);
    const content = String(b.content || "").trim().slice(0, 5000);
    const imageUrl = safeUrl(String(b.image_url || "").trim().slice(0, 500), true);
    const published = b.published !== false;

    if (!title) return bad(res, 400, "missing_title", "กรุณาระบุหัวข้อประกาศ");

    const list = await store.news();
    const post = {
      id: genId("news"),
      title,
      content,
      image_url: imageUrl,
      published,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    list.push(post);
    await store.writeNews(list);
    return res.status(201).json({ ok: true, id: post.id, post });
  });
}));

router.patch("/news/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const list = await store.news();
    const idx = list.findIndex((n) => String(n.id) === String(req.params.id));
    if (idx === -1) return bad(res, 404, "not_found", "ไม่พบประกาศ");

    const b = req.body || {};
    if (b.title !== undefined) list[idx].title = String(b.title).trim().slice(0, 200);
    if (b.content !== undefined) list[idx].content = String(b.content).trim().slice(0, 5000);
    if (b.image_url !== undefined) list[idx].image_url = safeUrl(String(b.image_url).slice(0, 500), true);
    if (b.published !== undefined) list[idx].published = Boolean(b.published);
    list[idx].updated_at = new Date().toISOString();

    await store.writeNews(list);
    return res.json({ ok: true, post: list[idx] });
  });
}));

router.delete("/news/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const list = (await store.news()).filter((n) => String(n.id) !== String(req.params.id));
    await store.writeNews(list);
    return res.json({ ok: true });
  });
}));

// ================================================================
// 9. PAYMENT CHANNELS (Local Store)
// ================================================================
router.get("/channels", asyncRoute(async (req, res) => {
  res.json({ channels: await store.paymentChannels() });
}));

router.post("/channels", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const b = req.body || {};
    const name_ = String(b.name || "").trim().slice(0, 100);
    const type = String(b.type || "bank").trim();
    const accountNo = String(b.account_no || "").trim().slice(0, 50);
    const accountName = String(b.account_name || "").trim().slice(0, 100);
    const bankName = String(b.bank_name || name_).trim().slice(0, 100);
    const qrImg = safeUrl(String(b.qr_img || "").trim().slice(0, 500), true) || null;

    if (!name_ || !accountNo || !accountName) {
      return bad(res, 400, "missing_fields", "กรุณากรอกชื่อธนาคาร เลขบัญชี และชื่อบัญชีให้ครบ");
    }

    const list = await store.paymentChannels();
    const ch = {
      id: genId("ch"),
      name: name_,
      type,
      account_no: accountNo,
      account_name: accountName,
      bank_name: bankName,
      qr_img: qrImg,
      enabled: true,
      sort_order: list.length + 1,
      created_at: new Date().toISOString(),
    };
    list.push(ch);
    await store.writePaymentChannels(list);
    return res.status(201).json({ ok: true, id: ch.id, channel: ch });
  });
}));

router.patch("/channels/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const id = String(req.params.id || "");
    const list = await store.paymentChannels();
    const idx = list.findIndex((c) => String(c.id) === id);
    if (idx === -1) return bad(res, 404, "not_found", "ไม่พบช่องทางชำระเงิน");

    const b = req.body || {};
    if (b.name !== undefined) {
      list[idx].name = String(b.name).trim().slice(0, 100);
      list[idx].bank_name = list[idx].name;
    }
    if (b.account_no !== undefined) list[idx].account_no = String(b.account_no).trim().slice(0, 50);
    if (b.account_name !== undefined) list[idx].account_name = String(b.account_name).trim().slice(0, 100);
    if (b.qr_img !== undefined) list[idx].qr_img = safeUrl(String(b.qr_img).trim().slice(0, 500), true) || null;
    if (b.enabled !== undefined) list[idx].enabled = Boolean(b.enabled);

    await store.writePaymentChannels(list);
    return res.json({ ok: true, channel: list[idx] });
  });
}));

router.delete("/channels/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const id = String(req.params.id || "");
    const list = (await store.paymentChannels()).filter((c) => String(c.id) !== id);
    await store.writePaymentChannels(list);
    return res.json({ ok: true });
  });
}));

// ================================================================
// 10. SITE SETTINGS
// ================================================================
router.get("/settings", asyncRoute(async (req, res) => {
  res.json({ settings: await store.settings() });
}));

router.patch("/settings", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const b = req.body || {};
    const patch = {};
    if (b.site_name !== undefined) patch.site_name = String(b.site_name).trim().slice(0, 100);
    if (b.truemoney_phone !== undefined) patch.truemoney_phone = String(b.truemoney_phone).replace(/\D/g, "").slice(0, 15);
    if (b.promptpay_id !== undefined) patch.promptpay_id = String(b.promptpay_id).replace(/\D/g, "").slice(0, 15);
    if (b.topup_mode !== undefined && ["direct", "disabled"].includes(b.topup_mode)) patch.topup_mode = b.topup_mode;
    if (b.banner_url !== undefined) patch.banner_url = safeUrl(String(b.banner_url).trim().slice(0, 500), true);
    if (b.discord_url !== undefined) patch.discord_url = safeUrl(String(b.discord_url).trim().slice(0, 500), false);
    if (b.maintenance !== undefined) patch.maintenance = Boolean(b.maintenance);

    const saved = await store.writeSettings(patch);

    // Sync discord_url to support_links if discord_url was updated
    if (patch.discord_url) {
      const supList = await store.supportLinks();
      const dIdx = supList.findIndex((x) => x.platform === "discord");
      if (dIdx >= 0) {
        supList[dIdx].url = patch.discord_url;
        await store.writeSupportLinks(supList);
      }
    }

    // Also try syncing to Supabase site_settings if available
    const client = db.getClient();
    if (client) {
      try {
        await client
          .from("site_settings")
          .update({
            site_name: saved.site_name,
            truemoney_phone: saved.truemoney_phone,
            topup_mode: saved.topup_mode,
            banner_url: saved.banner_url,
            maintenance: saved.maintenance,
          })
          .neq("id", "00000000-0000-0000-0000-000000000000");
      } catch (e) {}
    }

    return res.json({ ok: true, settings: saved });
  });
}));

// ================================================================
// 11. SUPPORT & CONTACT CHANNELS CRUD
// ================================================================
router.get("/support-links", asyncRoute(async (req, res) => {
  const rawLinks = await store.supportLinks();
  const links = (rawLinks || [])
    .sort((a, b) => (Number(a.sort_order) || 99) - (Number(b.sort_order) || 99));
  res.json({ links });
}));

router.post("/support-links", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const b = req.body || {};
    const platform = String(b.platform || "custom").trim().toLowerCase().slice(0, 32);
    const label = String(b.label || "").trim().slice(0, 100);
    const handle = String(b.handle || "").trim().slice(0, 120);
    const rawUrl = String(b.url || "").trim().slice(0, 500);
    const url = safeUrl(rawUrl, false) || (platform === "email" && rawUrl ? "mailto:" + rawUrl.replace(/^javascript:/i, "") : (platform === "phone" && rawUrl ? "tel:" + rawUrl.replace(/[^0-9+*#-]/g, "") : "#"));
    const badge = String(b.badge || "ติดต่อสอบถาม").trim().slice(0, 50);
    const description = String(b.description || "").trim().slice(0, 300);

    if (!label) return bad(res, 400, "missing_label", "กรุณาระบุชื่อช่องทางติดต่อ");
    if (!url && !handle) return bad(res, 400, "missing_url", "กรุณาระบุลิงก์ URL หรือไอดีติดต่อ");

    const list = await store.supportLinks();
    const item = {
      id: "sup_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      platform,
      label,
      handle: handle || url,
      url: url || "#",
      badge: badge || "ออนไลน์",
      description: description || "ติดต่อสอบถามข้อมูลหรือแจ้งปัญหาผ่านช่องทางนี้",
      enabled: b.enabled !== false,
      sort_order: Number.isFinite(Number(b.sort_order)) ? Number(b.sort_order) : list.length + 1,
      created_at: new Date().toISOString(),
    };

    list.push(item);
    await store.writeSupportLinks(list);
    return res.status(201).json({ ok: true, link: item });
  });
}));

router.patch("/support-links/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const id = String(req.params.id || "");
    const list = await store.supportLinks();
    const idx = (list || []).findIndex((x) => String(x.id) === id);
    if (idx === -1) return bad(res, 404, "not_found", "ไม่พบช่องทางติดต่อนี้");

    const b = req.body || {};
    if (b.platform !== undefined) list[idx].platform = String(b.platform).trim().toLowerCase().slice(0, 32);
    if (b.label !== undefined) list[idx].label = String(b.label).trim().slice(0, 100);
    if (b.handle !== undefined) list[idx].handle = String(b.handle).trim().slice(0, 120);
    if (b.url !== undefined) {
      const rawU = String(b.url).trim().slice(0, 500);
      const pf = list[idx].platform || "custom";
      list[idx].url = safeUrl(rawU, false) || (pf === "email" && rawU ? "mailto:" + rawU.replace(/^javascript:/i, "") : (pf === "phone" && rawU ? "tel:" + rawU.replace(/[^0-9+*#-]/g, "") : "#"));
    }
    if (b.badge !== undefined) list[idx].badge = String(b.badge).trim().slice(0, 50);
    if (b.description !== undefined) list[idx].description = String(b.description).trim().slice(0, 300);
    if (b.enabled !== undefined) list[idx].enabled = Boolean(b.enabled);
    if (b.sort_order !== undefined && Number.isFinite(Number(b.sort_order))) {
      list[idx].sort_order = Number(b.sort_order);
    }
    list[idx].updated_at = new Date().toISOString();

    await store.writeSupportLinks(list);
    return res.json({ ok: true, link: list[idx] });
  });
}));

router.delete("/support-links/:id", asyncRoute(async (req, res) => {
  return store.withLock("admin-config", async () => {
    const id = String(req.params.id || "");
    const next = (await store.supportLinks()).filter((x) => String(x.id) !== id);
    await store.writeSupportLinks(next);
    return res.json({ ok: true });
  });
}));

module.exports = router;
