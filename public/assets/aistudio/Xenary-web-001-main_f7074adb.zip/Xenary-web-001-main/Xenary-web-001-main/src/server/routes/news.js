// GET  /api/news          – list published posts (public)
// GET  /api/news/:id      – single post (public)
const express = require("express");
const asyncRoute = require("../lib/async-route");
const store = require("../lib/store");

const router = express.Router();

function fromRow(row) {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    imageUrl: row.image_url || row.imageUrl || "",
    published: row.published !== false,
    createdAt: row.created_at || row.createdAt,
    updatedAt: row.updated_at || row.updatedAt,
  };
}

router.get("/", asyncRoute(async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 20, 50);
  const rawPosts = await store.news();
  const posts = (rawPosts || [])
    .filter((p) => p.published !== false)
    .slice(-limit)
    .reverse()
    .map(fromRow);
  res.json({ posts });
}));

router.get("/:id", asyncRoute(async (req, res) => {
  const rawPosts = await store.news();
  const post = (rawPosts || []).find((p) => String(p.id) === String(req.params.id) && p.published !== false);
  if (!post) return res.status(404).json({ error: "not_found", message: "ไม่พบบทความ" });
  res.json({ post: fromRow(post) });
}));

module.exports = router;
