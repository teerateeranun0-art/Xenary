# XENARY — เว็บร้านค้า + backend

```bash
npm install
npm start      # http://localhost:3000   (PORT=8080 เปลี่ยนพอร์ต)
```

## หน้าเว็บ
`/` หน้าแรก (แบนเนอร์, หมวดหมู่, รายการสั่งซื้อล่าสุด, สินค้า) · `/products/` สินค้าทั้งหมด · `/status/` สถานะระบบ · `/tos/` เงื่อนไข · `/contact/` ติดต่อ · `/login/` `/register/` สมาชิก · `/account/` กระเป๋าเงิน + เติมเงิน · `/admin/` แอดมิน (ต้องมี ADMIN_KEY)

## ตั้งค่าครั้งแรก
1. `npm install` 2. คัดลอก `.env.example` เป็น `.env` แล้วใส่ `PROMPTPAY_ID`, `TRUEMONEY_PHONE`, `ADMIN_KEY`
3. ทดสอบโดยไม่ใช้เงินจริง: ตั้ง `DEMO_PAYMENTS=1` (ห้ามเปิดตอนขายจริง)

## ระบบสมาชิก / เติมเงิน
- สมัคร/เข้าสู่ระบบด้วยชื่อผู้ใช้ + รหัสผ่าน (เข้ารหัสแบบ scrypt, session เป็น HttpOnly cookie, ติ๊ก "จดจำฉัน" = อยู่ได้ 30 วัน)
- กันบอท: รูปรหัสยืนยัน (captcha) + ช่องล่อบอท + จำกัดจำนวนครั้งต่อ IP + ล็อกบัญชี 5 นาทีเมื่อใส่รหัสผิด 5 ครั้ง
- เติมเงินด้วยซองอั่งเปา TrueMoney: ระบบแลกซองเข้าเบอร์ `TRUEMONEY_PHONE` แล้วเพิ่มยอดให้อัตโนมัติ (ใช้ endpoint สาธารณะของ TrueMoney ไม่ใช่ API ทางการ ทดสอบด้วยซองเล็กก่อน)
- เติมเงินด้วย QR พร้อมเพย์: สร้าง QR พร้อมเศษสตางค์ไม่ซ้ำ แล้วแอดมินยืนยันที่ `/admin/` หลังเช็กยอดเข้าบัญชี
- สั่งซื้อหักจากยอดเงินในบัญชี สถานะออเดอร์ `paid` แล้วแอดมินกด "ส่งมอบแล้ว"
- ข้อมูลอยู่ใน `src/data/users.json`, `topups.json`, `sessions.json` (อยู่ใน .gitignore ห้ามแชร์)

## แก้ของ
- สินค้า/ราคา/สต็อก: `src/data/products.json`
- ลิงก์ Discord: `DISCORD_URL` ใน `assets/js/site.js`
- โลโก้/แบนเนอร์: `assets/img/logo.png`, `assets/img/banner.jpg`
- หน้าตาร้าน: `src/client/shop/shop.css`, `assets/css/site.css`

## API
`POST /api/auth/register|login|logout` · `GET /api/auth/me` · `POST /api/wallet/truemoney|promptpay` · `GET /api/wallet/topups` · `GET /api/products` · `GET /api/products/:slug` · `POST /api/orders` · `GET /api/orders/recent` · `PATCH /api/orders/:id` · `GET /api/status` · `GET /health`
