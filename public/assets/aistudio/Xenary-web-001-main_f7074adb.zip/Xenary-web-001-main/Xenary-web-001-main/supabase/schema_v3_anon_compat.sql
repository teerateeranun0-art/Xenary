-- ============================================================
--  XENARY  -  anon-key compatibility (undo schema_v3_lockdown.sql)
--
--  Use this ONLY if the server keeps running with SUPABASE_PUBLISHABLE_KEY
--  (SUPABASE_SERVICE_ROLE_KEY empty). It gives the anon role the access the
--  Node server needs on exactly these tables:
--     products, users, sessions, orders, topups, site_settings
--  and removes the balance/role trigger, because that trigger rejects every
--  balance change made by the anon role.
--
--  SECURITY TRADE-OFF: anyone holding the publishable key can read users.pass
--  (password hashes) and edit balances / roles through the Supabase REST API.
--  The proper fix is a service_role key + schema_v3_lockdown.sql.
--  Run in Supabase SQL Editor. Safe to re-run.
-- ============================================================

begin;

grant usage on schema public to anon, authenticated;

do $compat$
declare
  t text;
begin
  foreach t in array array['products','users','sessions','orders','topups','site_settings'] loop
    if to_regclass('public.' || t) is null then
      raise notice 'table % not found - skipped', t;
      continue;
    end if;

    execute format('grant select, insert, update, delete on public.%I to anon, authenticated', t);
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists xenary_app_access on public.%I', t);
    execute format(
      'create policy xenary_app_access on public.%I for all to anon, authenticated using (true) with check (true)',
      t
    );
  end loop;
end;
$compat$;

grant usage, select on all sequences in schema public to anon, authenticated;

-- anon cannot change balance/role while this trigger exists
drop trigger if exists trg_users_protect_balance on public.users;

commit;

-- Verify (run as anon via the app, or in the SQL editor):
--   select policyname, tablename from pg_policies where policyname = 'xenary_app_access';
