-- ============================================================
--  XENARY SITE  –  Migration v2
--  Features: product_keys, coupons, manual_topups, payment_channels,
--            news_posts, support_links, site_settings,
--            protect_balance trigger, add/deduct balance RPCs,
--            redeem_coupon RPC, truemoney direct topup log
--
--  Run AFTER schema.sql in Supabase SQL Editor
-- ============================================================


-- ============================================================
-- A. NEW COLUMNS ON EXISTING TABLES
-- ============================================================

-- products: key-based delivery flag + download_url
alter table products
  add column if not exists key_based    boolean not null default false,
  add column if not exists download_url text    default '';

-- orders: key delivered at, keys array (filled after delivery)
alter table orders
  add column if not exists keys_delivered jsonb    default '[]'::jsonb,
  add column if not exists delivered_at   timestamptz;

-- topups: voucher_code for TrueMoney dedup
alter table topups
  add column if not exists voucher_code text,
  add column if not exists provider_response jsonb;

-- unique index: one successful redemption per voucher
create unique index if not exists topups_voucher_success_idx
  on topups (voucher_code)
  where voucher_code is not null and status = 'approved';


-- ============================================================
-- B. PRODUCT KEYS
-- ============================================================

create table if not exists product_keys (
  id          uuid        primary key default gen_random_uuid(),
  product_id  text        not null references products(id) on delete cascade,
  key_value   text        not null,
  is_used     boolean     not null default false,
  order_id    text        references orders(id) on delete set null,
  created_at  timestamptz not null default now()
);

alter table product_keys enable row level security;

drop policy if exists "product_keys_service_all" on product_keys;
create policy "product_keys_service_all"
  on product_keys for all to service_role
  using (true) with check (true);

-- users see keys only for their own completed orders
drop policy if exists "product_keys_owner_read" on product_keys;
create policy "product_keys_owner_read"
  on product_keys for select
  using (
    order_id is not null and exists (
      select 1 from orders o
      where o.id = product_keys.order_id
        and o.user_id = current_setting('app.user_id', true)
    )
  );

create index if not exists idx_product_keys_product   on product_keys (product_id) where is_used = false;
create index if not exists idx_product_keys_order      on product_keys (order_id);


-- ============================================================
-- C. COUPONS
-- ============================================================

create table if not exists coupons (
  id            uuid        primary key default gen_random_uuid(),
  code          text        not null unique,
  amount        numeric(12,2) not null check (amount > 0),
  max_uses      integer,
  uses_count    integer     not null default 0,
  per_user_limit integer    not null default 1,
  enabled       boolean     not null default true,
  expires_at    timestamptz,
  note          text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists coupon_redemptions (
  id          uuid        primary key default gen_random_uuid(),
  coupon_id   uuid        not null references coupons(id) on delete cascade,
  user_id     text        not null references users(id) on delete cascade,
  amount      numeric(12,2) not null,
  created_at  timestamptz not null default now()
);

alter table coupons              enable row level security;
alter table coupon_redemptions   enable row level security;

drop policy if exists "coupons_service_all"            on coupons;
drop policy if exists "coupon_redemptions_service_all" on coupon_redemptions;
drop policy if exists "coupon_redemptions_own_read"    on coupon_redemptions;

create policy "coupons_service_all"
  on coupons for all to service_role using (true) with check (true);

create policy "coupon_redemptions_service_all"
  on coupon_redemptions for all to service_role using (true) with check (true);

create policy "coupon_redemptions_own_read"
  on coupon_redemptions for select
  using (user_id = current_setting('app.user_id', true));

create index if not exists idx_coupons_code          on coupons (lower(code));
create index if not exists idx_coupon_redemptions_uid on coupon_redemptions (user_id, coupon_id);

-- Trigger updated_at on coupons
drop trigger if exists trg_coupons_updated_at on coupons;
create trigger trg_coupons_updated_at
  before update on coupons
  for each row execute function fn_set_updated_at();

-- RPC: redeem_coupon (atomic, race-safe)
create or replace function fn_redeem_coupon(
  p_user_id text,
  p_code    text
)
returns jsonb language plpgsql security definer as $$
declare
  v_coupon   coupons%rowtype;
  v_used_by  integer;
begin
  -- lock the coupon row
  select * into v_coupon
  from coupons
  where lower(code) = lower(p_code)
  for update;

  if not found then
    return jsonb_build_object('success', false, 'message', 'ไม่พบคูปอง');
  end if;
  if not v_coupon.enabled then
    return jsonb_build_object('success', false, 'message', 'คูปองถูกปิดใช้งาน');
  end if;
  if v_coupon.expires_at is not null and v_coupon.expires_at < now() then
    return jsonb_build_object('success', false, 'message', 'คูปองหมดอายุ');
  end if;
  if v_coupon.max_uses is not null and v_coupon.uses_count >= v_coupon.max_uses then
    return jsonb_build_object('success', false, 'message', 'คูปองถูกใช้ครบแล้ว');
  end if;

  select count(*) into v_used_by
  from coupon_redemptions
  where coupon_id = v_coupon.id and user_id = p_user_id;

  if v_used_by >= v_coupon.per_user_limit then
    return jsonb_build_object('success', false, 'message', 'คุณใช้คูปองนี้ครบสิทธิ์แล้ว');
  end if;

  -- credit balance
  update users
    set balance  = balance + v_coupon.amount::integer,
        updated_at = now()
  where id = p_user_id;

  -- record redemption
  insert into coupon_redemptions (coupon_id, user_id, amount)
  values (v_coupon.id, p_user_id, v_coupon.amount);

  -- increment counter
  update coupons
    set uses_count = uses_count + 1, updated_at = now()
  where id = v_coupon.id;

  -- audit
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_user_id, 'coupon.redeemed', 'coupon', v_coupon.id::text,
          jsonb_build_object('code', v_coupon.code, 'amount', v_coupon.amount));

  return jsonb_build_object('success', true, 'amount', v_coupon.amount, 'message', 'สำเร็จ');
end;
$$;


-- ============================================================
-- D. PAYMENT CHANNELS
-- ============================================================

create table if not exists payment_channels (
  id          uuid        primary key default gen_random_uuid(),
  name        text        not null,
  type        text        not null check (type in ('promptpay','bank','truemoney','other')),
  account_no  text        not null,
  account_name text       not null,
  bank_name   text,
  qr_img      text,
  enabled     boolean     not null default true,
  sort_order  integer     not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table payment_channels enable row level security;

drop policy if exists "payment_channels_public_read" on payment_channels;
drop policy if exists "payment_channels_service_all" on payment_channels;

create policy "payment_channels_public_read"
  on payment_channels for select using (enabled = true);

create policy "payment_channels_service_all"
  on payment_channels for all to service_role
  using (true) with check (true);

drop trigger if exists trg_payment_channels_updated_at on payment_channels;
create trigger trg_payment_channels_updated_at
  before update on payment_channels
  for each row execute function fn_set_updated_at();

-- Seed default channel
insert into payment_channels (name, type, account_no, account_name, bank_name, enabled, sort_order)
values ('PromptPay', 'promptpay', '0812345678', 'ร้าน XENARY', null, true, 1)
on conflict do nothing;


-- ============================================================
-- E. MANUAL TOPUPS  (slip-based, admin approve/reject)
-- ============================================================

create table if not exists manual_topups (
  id            uuid        primary key default gen_random_uuid(),
  user_id       text        not null references users(id) on delete cascade,
  channel_id    uuid        not null references payment_channels(id),
  amount        numeric(12,2) not null check (amount > 0),
  slip_url      text,
  status        text        not null default 'pending'
                  check (status in ('pending','approved','rejected')),
  admin_note    text,
  approved_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

alter table manual_topups enable row level security;

drop policy if exists "manual_topups_own_read"    on manual_topups;
drop policy if exists "manual_topups_own_insert"  on manual_topups;
drop policy if exists "manual_topups_service_all" on manual_topups;

create policy "manual_topups_own_read"
  on manual_topups for select
  using (user_id = current_setting('app.user_id', true));

create policy "manual_topups_own_insert"
  on manual_topups for insert
  with check (user_id = current_setting('app.user_id', true));

create policy "manual_topups_service_all"
  on manual_topups for all to service_role
  using (true) with check (true);

create index if not exists idx_manual_topups_user   on manual_topups (user_id, created_at desc);
create index if not exists idx_manual_topups_status on manual_topups (status) where status = 'pending';

drop trigger if exists trg_manual_topups_updated_at on manual_topups;
create trigger trg_manual_topups_updated_at
  before update on manual_topups
  for each row execute function fn_set_updated_at();


-- ============================================================
-- F. NEWS / POSTS
-- ============================================================

create table if not exists news_posts (
  id          uuid        primary key default gen_random_uuid(),
  title       text        not null,
  content     text        not null default '',
  image_url   text        default '',
  published   boolean     not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table news_posts enable row level security;

drop policy if exists "news_posts_public_read"   on news_posts;
drop policy if exists "news_posts_service_all"   on news_posts;

create policy "news_posts_public_read"
  on news_posts for select using (published = true);

create policy "news_posts_service_all"
  on news_posts for all to service_role
  using (true) with check (true);

create index if not exists idx_news_posts_published on news_posts (created_at desc) where published = true;

drop trigger if exists trg_news_posts_updated_at on news_posts;
create trigger trg_news_posts_updated_at
  before update on news_posts
  for each row execute function fn_set_updated_at();


-- ============================================================
-- G. SUPPORT LINKS
-- ============================================================

create table if not exists support_links (
  id          uuid        primary key default gen_random_uuid(),
  platform    text        not null,
  label       text        not null,
  url         text        not null,
  icon_url    text,
  color       text,
  description text,
  sort_order  integer     not null default 0,
  is_active   boolean     not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table support_links enable row level security;

drop policy if exists "support_links_public_read" on support_links;
drop policy if exists "support_links_service_all" on support_links;

create policy "support_links_public_read"
  on support_links for select using (is_active = true);

create policy "support_links_service_all"
  on support_links for all to service_role
  using (true) with check (true);

drop trigger if exists trg_support_links_updated_at on support_links;
create trigger trg_support_links_updated_at
  before update on support_links
  for each row execute function fn_set_updated_at();

-- Seed default support links
insert into support_links (platform, label, url, color, description, sort_order)
values
  ('discord', 'Discord', 'https://discord.gg/', '#5865F2', 'พูดคุยและรับข่าวสาร', 1),
  ('line',    'LINE',    'https://line.me/',    '#06C755', 'ติดต่อแอดมิน 24 ชม.', 2)
on conflict do nothing;


-- ============================================================
-- H. SITE SETTINGS
-- ============================================================

create table if not exists site_settings (
  id              uuid        primary key default gen_random_uuid(),
  site_name       text        not null default 'XENARY',
  truemoney_phone text        not null default '',
  topup_mode      text        not null default 'direct'
                    check (topup_mode in ('direct','disabled')),
  banner_url      text        default '',
  maintenance     boolean     not null default false,
  updated_at      timestamptz not null default now()
);

alter table site_settings enable row level security;

drop policy if exists "site_settings_public_read" on site_settings;
drop policy if exists "site_settings_service_all" on site_settings;

create policy "site_settings_public_read"
  on site_settings for select using (true);

create policy "site_settings_service_all"
  on site_settings for all to service_role
  using (true) with check (true);

drop trigger if exists trg_site_settings_updated_at on site_settings;
create trigger trg_site_settings_updated_at
  before update on site_settings
  for each row execute function fn_set_updated_at();

-- Insert default (once only)
insert into site_settings (site_name, truemoney_phone, topup_mode)
values ('XENARY', '', 'direct')
on conflict do nothing;


-- ============================================================
-- I. PROTECT BALANCE TRIGGER
--    ป้องกัน balance ถูกแก้โดยตรง — ต้องใช้ fn เท่านั้น
-- ============================================================

create or replace function fn_protect_balance()
returns trigger language plpgsql security definer as $$
begin
  -- service_role bypass: current_setting returns '' when not set
  if current_setting('app.user_id', true) = '' then
    return new;
  end if;
  -- ห้าม user แก้ balance โดยตรง
  if new.balance is distinct from old.balance then
    raise exception 'ไม่อนุญาตให้แก้ไข balance โดยตรง';
  end if;
  if new.role is distinct from old.role then
    raise exception 'ไม่อนุญาตให้แก้ไข role โดยตรง';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_users_protect_balance on users;
create trigger trg_users_protect_balance
  before update on users
  for each row execute function fn_protect_balance();


-- ============================================================
-- J. add_balance / deduct_balance RPCs
--    ใช้จาก server-side เท่านั้น (service_role)
-- ============================================================

create or replace function fn_add_balance(
  p_user_id text,
  p_amount  numeric
)
returns numeric language plpgsql security definer as $$
declare v_new numeric;
begin
  if p_amount <= 0 then
    raise exception 'amount must be positive';
  end if;
  update users
    set balance    = balance + p_amount::integer,
        updated_at = now()
  where id = p_user_id
  returning balance into v_new;
  if not found then
    raise exception 'user not found: %', p_user_id;
  end if;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_user_id, 'balance.credit', 'user', p_user_id,
          jsonb_build_object('amount', p_amount, 'new_balance', v_new));
  return v_new;
end;
$$;

create or replace function fn_deduct_balance(
  p_user_id text,
  p_amount  numeric
)
returns numeric language plpgsql security definer as $$
declare v_new numeric;
begin
  if p_amount <= 0 then
    raise exception 'amount must be positive';
  end if;
  update users
    set balance    = balance - p_amount::integer,
        updated_at = now()
  where id = p_user_id
    and balance >= p_amount::integer   -- guard: block if insufficient
  returning balance into v_new;
  if not found then
    raise exception 'insufficient_balance';
  end if;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_user_id, 'balance.debit', 'user', p_user_id,
          jsonb_build_object('amount', p_amount, 'new_balance', v_new));
  return v_new;
end;
$$;


-- ============================================================
-- K. UPDATE EXISTING FUNCTIONS  (use fn_add/deduct_balance)
-- ============================================================

-- fn_approve_topup: now uses fn_add_balance
create or replace function fn_approve_topup(
  p_topup_id  text,
  p_actor_id  text default null
)
returns void language plpgsql security definer as $$
declare v_topup topups%rowtype;
begin
  select * into v_topup from topups where id = p_topup_id for update;
  if not found then raise exception 'topup not found: %', p_topup_id; end if;
  if v_topup.status <> 'pending' then
    raise exception 'topup % is not pending (status: %)', p_topup_id, v_topup.status;
  end if;
  perform fn_add_balance(v_topup.uid, v_topup.amount::numeric);
  update topups set status = 'approved', updated_at = now() where id = p_topup_id;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'topup.approved', 'topup', p_topup_id,
          jsonb_build_object('uid', v_topup.uid, 'amount', v_topup.amount));
end;
$$;

-- fn_approve_manual_topup
create or replace function fn_approve_manual_topup(
  p_manual_topup_id uuid,
  p_actor_id        text default null,
  p_note            text default null
)
returns void language plpgsql security definer as $$
declare v_mt manual_topups%rowtype;
begin
  select * into v_mt from manual_topups where id = p_manual_topup_id for update;
  if not found then raise exception 'manual topup not found: %', p_manual_topup_id; end if;
  if v_mt.status <> 'pending' then
    raise exception 'manual topup % is not pending (status: %)', p_manual_topup_id, v_mt.status;
  end if;
  perform fn_add_balance(v_mt.user_id, v_mt.amount);
  update manual_topups
    set status      = 'approved',
        admin_note  = coalesce(p_note, admin_note),
        approved_at = now(),
        updated_at  = now()
  where id = p_manual_topup_id;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'manual_topup.approved', 'manual_topup', p_manual_topup_id::text,
          jsonb_build_object('user_id', v_mt.user_id, 'amount', v_mt.amount));
end;
$$;

-- fn_refund_order: now uses fn_add_balance
create or replace function fn_refund_order(
  p_order_id  text,
  p_actor_id  text default null
)
returns void language plpgsql security definer as $$
declare v_order orders%rowtype;
begin
  select * into v_order from orders where id = p_order_id for update;
  if not found then raise exception 'order not found: %', p_order_id; end if;
  if v_order.status not in ('paid','completed') then
    raise exception 'order % cannot be refunded (status: %)', p_order_id, v_order.status;
  end if;
  if v_order.user_id is not null then
    perform fn_add_balance(v_order.user_id, v_order.total);
  end if;
  update orders set status = 'refunded', updated_at = now() where id = p_order_id;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'order.refunded', 'order', p_order_id,
          jsonb_build_object('user_id', v_order.user_id, 'total', v_order.total));
end;
$$;


-- ============================================================
-- L. UPDATE DASHBOARD STATS
-- ============================================================

create or replace function fn_dashboard_stats()
returns jsonb language sql stable as $$
  select jsonb_build_object(
    'total_users',          (select count(*) from users),
    'total_orders',         (select count(*) from orders),
    'total_revenue',        (select coalesce(sum(total),0) from orders where status in ('paid','completed')),
    'pending_topups',       (select count(*) from topups       where status = 'pending'),
    'pending_manual_topups',(select count(*) from manual_topups where status = 'pending'),
    'orders_today',         (select count(*) from orders       where created_at >= current_date),
    'revenue_today',        (select coalesce(sum(total),0) from orders where status in ('paid','completed') and created_at >= current_date),
    'active_products',      (select count(*) from products     where active = true),
    'low_stock_products',   (select count(*) from products     where stock <= 3 and active = true),
    'active_coupons',       (select count(*) from coupons      where enabled = true and (expires_at is null or expires_at > now()))
  );
$$;


-- ============================================================
-- M. UPDATED VIEWS
-- ============================================================

create or replace view v_manual_topups as
select
  mt.*,
  u.username,
  pc.name  as channel_name,
  pc.type  as channel_type
from manual_topups mt
join users           u  on u.id  = mt.user_id
join payment_channels pc on pc.id = mt.channel_id;


-- ============================================================
-- N. USEFUL QUERIES FOR NEW FEATURES
-- ============================================================

-- Pending manual topups
-- select * from v_manual_topups where status = 'pending' order by created_at;

-- Approve manual topup
-- select fn_approve_manual_topup('<uuid>', '<admin_user_id>');

-- Reject manual topup
-- update manual_topups set status='rejected', admin_note='สลิปไม่ตรง' where id='<uuid>';

-- Redeem coupon for user
-- select fn_redeem_coupon('<user_id>', 'PROMO50');

-- Add product key
-- insert into product_keys (product_id, key_value) values ('<product_id>', 'XXXX-XXXX-XXXX');

-- List unused keys per product
-- select product_id, count(*) as unused from product_keys where is_used = false group by product_id;

-- All support links
-- select * from support_links order by sort_order;

-- All payment channels
-- select * from payment_channels order by sort_order;

-- Site settings
-- select * from site_settings limit 1;
