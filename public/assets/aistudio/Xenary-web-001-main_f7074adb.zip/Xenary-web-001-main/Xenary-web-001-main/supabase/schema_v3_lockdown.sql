-- ============================================================
--  XENARY  -  Lockdown v3  (run LAST, after schema_v3_reorganize.sql)
--
--  !! BEFORE RUNNING !!
--  The server currently connects with SUPABASE_PUBLISHABLE_KEY (the anon role)
--  because SUPABASE_SERVICE_ROLE_KEY is empty. This script removes ALL anon /
--  authenticated access to the public schema. Put the service_role key in
--  .env (server side only, never in browser files), restart the server, confirm
--  /api/products loads, THEN run this file. Otherwise the whole site loses its
--  database connection.
--
--  Why: with the publishable key anyone could read users.pass (password hashes)
--  and insert users / sessions. Nothing in the browser talks to Supabase
--  directly (verified: no supabase usage in assets/ or src/client/), so no
--  client-side policy is needed.
-- ============================================================

begin;

-- permissive anon policies from schema.sql
drop policy if exists users_insert_anon    on users;
drop policy if exists sessions_insert_anon on sessions;
drop policy if exists sessions_delete_anon on sessions;

-- no table / sequence / function access for browser-facing roles
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;

grant usage on schema public to service_role;
grant all on all tables    in schema public to service_role;
grant all on all sequences in schema public to service_role;
grant execute on all functions in schema public to service_role;

-- future objects created by the postgres role stay private by default
alter default privileges for role postgres in schema public revoke all on tables    from anon, authenticated;
alter default privileges for role postgres in schema public revoke all on sequences from anon, authenticated;
alter default privileges for role postgres in schema public revoke execute on functions from public, anon, authenticated;

-- RLS stays on everywhere (service_role bypasses it)
do $rls$
declare t text;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end;
$rls$;

commit;

-- Verify: should return zero rows
--   select grantee, table_name, privilege_type
--   from information_schema.role_table_grants
--   where table_schema = 'public' and grantee in ('anon','authenticated');
