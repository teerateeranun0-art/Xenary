-- ============================================================
--  XENARY STORE  –  Complete Production Schema for Lovable / Supabase
--  Designed for Public/Anon API Key without requiring Service Role
--  Run in Supabase / Lovable Cloud SQL Editor (Idempotent & Safe)
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- 1. Grant Schema Usage
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- ------------------------------------------------------------
-- 2. ALTER EXISTING TABLES (Add missing columns idempotently)
-- ------------------------------------------------------------

-- 2.1 PRODUCTS
CREATE TABLE IF NOT EXISTS public.products (
  id          TEXT PRIMARY KEY,
  slug        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS channel      TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS tag          TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS description  TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS stock        INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  ADD COLUMN IF NOT EXISTS sold         INTEGER NOT NULL DEFAULT 0 CHECK (sold >= 0),
  ADD COLUMN IF NOT EXISTS best_seller  BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS featured     BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS active       BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS key_based    BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS img          TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS download_url TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS plans        JSONB NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- 2.2 USERS
CREATE TABLE IF NOT EXISTS public.users (
  id          TEXT PRIMARY KEY,
  username    TEXT UNIQUE NOT NULL,
  pass        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS balance    BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  ADD COLUMN IF NOT EXISTS role       TEXT NOT NULL DEFAULT 'user',
  ADD COLUMN IF NOT EXISTS banned     BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- 2.3 SESSIONS
CREATE TABLE IF NOT EXISTS public.sessions (
  id          TEXT PRIMARY KEY,
  h           TEXT UNIQUE NOT NULL,
  uid         TEXT NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  exp         BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.sessions
  ADD COLUMN IF NOT EXISTS ip         TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS user_agent TEXT DEFAULT '';

-- 2.4 ORDERS
CREATE TABLE IF NOT EXISTS public.orders (
  id          TEXT PRIMARY KEY,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS user_id        TEXT REFERENCES public.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS status         TEXT NOT NULL DEFAULT 'paid',
  ADD COLUMN IF NOT EXISTS product        JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS plan           JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS unit_price     NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  ADD COLUMN IF NOT EXISTS quantity       INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 1),
  ADD COLUMN IF NOT EXISTS total          NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  ADD COLUMN IF NOT EXISTS currency       TEXT NOT NULL DEFAULT '฿',
  ADD COLUMN IF NOT EXISTS contact        TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS note           TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS keys_delivered JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS download_url   TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS paid_at        TIMESTAMPTZ DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS delivered_at   TIMESTAMPTZ DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- 2.5 TOPUPS
CREATE TABLE IF NOT EXISTS public.topups (
  id          TEXT PRIMARY KEY,
  uid         TEXT NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.topups
  ADD COLUMN IF NOT EXISTS method            TEXT NOT NULL DEFAULT 'promptpay',
  ADD COLUMN IF NOT EXISTS amount            BIGINT NOT NULL DEFAULT 0 CHECK (amount >= 0),
  ADD COLUMN IF NOT EXISTS status            TEXT NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS ref               TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS note              TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS voucher_code      TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS provider_response JSONB DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS expires_at        TIMESTAMPTZ DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- 2.6 PRODUCT KEYS
CREATE TABLE IF NOT EXISTS public.product_keys (
  id          TEXT PRIMARY KEY,
  product_id  TEXT NOT NULL,
  key_value   TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.product_keys
  ADD COLUMN IF NOT EXISTS plan_label TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS is_used    BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS order_id   TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS used_at    TIMESTAMPTZ DEFAULT NULL;

-- 2.7 COUPONS
CREATE TABLE IF NOT EXISTS public.coupons (
  id          TEXT PRIMARY KEY,
  code        TEXT UNIQUE NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.coupons
  ADD COLUMN IF NOT EXISTS discount   NUMERIC(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS type       TEXT NOT NULL DEFAULT 'percent',
  ADD COLUMN IF NOT EXISTS max_uses   INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS used_count INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS enabled    BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ DEFAULT NULL;

-- 2.8 SITE SETTINGS (Add all missing columns to existing table)
CREATE TABLE IF NOT EXISTS public.site_settings (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name   TEXT NOT NULL DEFAULT 'XENARY',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS truemoney_phone TEXT DEFAULT '0812345678',
  ADD COLUMN IF NOT EXISTS promptpay_id    TEXT DEFAULT '0812345678',
  ADD COLUMN IF NOT EXISTS topup_mode      TEXT DEFAULT 'direct',
  ADD COLUMN IF NOT EXISTS banner_url      TEXT DEFAULT '/assets/img/banner.jpg',
  ADD COLUMN IF NOT EXISTS discord_url     TEXT DEFAULT 'https://discord.gg/xenary',
  ADD COLUMN IF NOT EXISTS line_url        TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS facebook_url    TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS announcement    TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS maintenance     BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW();

-- Update default settings columns for existing rows
UPDATE public.site_settings
SET
  promptpay_id = COALESCE(promptpay_id, '0812345678'),
  truemoney_phone = COALESCE(truemoney_phone, '0812345678'),
  discord_url = COALESCE(discord_url, 'https://discord.gg/xenary'),
  topup_mode = COALESCE(topup_mode, 'direct'),
  banner_url = COALESCE(banner_url, '/assets/img/banner.jpg')
WHERE promptpay_id IS NULL OR discord_url IS NULL;

-- 2.9 NEWS & POSTS
CREATE TABLE IF NOT EXISTS public.news_posts (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,
  pinned      BOOLEAN NOT NULL DEFAULT FALSE,
  published   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.10 PAYMENT CHANNELS
CREATE TABLE IF NOT EXISTS public.payment_channels (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL,
  account_no  TEXT DEFAULT '',
  account_name TEXT DEFAULT '',
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.11 MANUAL TOPUPS
CREATE TABLE IF NOT EXISTS public.manual_topups (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  channel_id  TEXT DEFAULT NULL,
  amount      NUMERIC(14,2) NOT NULL DEFAULT 0,
  slip_url    TEXT DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'pending',
  admin_note  TEXT DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.12 AUDIT LOG
CREATE TABLE IF NOT EXISTS public.audit_log (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    TEXT DEFAULT '',
  action      TEXT NOT NULL,
  target_type TEXT DEFAULT '',
  target_id   TEXT DEFAULT '',
  old_data    JSONB DEFAULT NULL,
  new_data    JSONB DEFAULT NULL,
  ip          TEXT DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- 3. PERMISSIONS & RLS POLICIES (Full Access for Anon, Authenticated & Service Role)
-- ------------------------------------------------------------

DO $$
DECLARE
  tbl text;
BEGIN
  FOR tbl IN
    SELECT tablename FROM pg_tables WHERE schemaname = 'public'
  LOOP
    EXECUTE format('GRANT ALL ON TABLE public.%I TO anon, authenticated, service_role;', tbl);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', tbl);
    EXECUTE format('DROP POLICY IF EXISTS xenary_allow_all ON public.%I;', tbl);
    EXECUTE format('CREATE POLICY xenary_allow_all ON public.%I FOR ALL TO anon, authenticated, service_role USING (true) WITH CHECK (true);', tbl);
  END LOOP;
END $$;

GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL ROUTINES IN SCHEMA public TO anon, authenticated, service_role;

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON ROUTINES TO anon, authenticated, service_role;

-- 4. ถอด Trigger ที่สกัดกั้นการแก้ยอดเงิน
DROP TRIGGER IF EXISTS trg_users_protect_balance ON public.users;
DROP FUNCTION IF EXISTS public.fn_protect_balance();
