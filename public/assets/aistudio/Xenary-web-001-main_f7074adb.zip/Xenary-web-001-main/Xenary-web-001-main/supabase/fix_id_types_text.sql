-- ================================================================
-- FIX VIEW DEPENDENCIES, ALL FOREIGN KEYS & ID TYPES (UUID -> TEXT)
-- รันชุดนี้ใน Supabase Dashboard -> SQL Editor ได้ทันที
-- ================================================================

-- 1. DROP Views ที่ผูกคอลัมน์ไว้ชั่วคราว
DROP VIEW IF EXISTS public.v_manual_topups CASCADE;
DROP VIEW IF EXISTS public.v_orders CASCADE;
DROP VIEW IF EXISTS public.v_topups CASCADE;
DROP VIEW IF EXISTS public.v_products CASCADE;
DROP VIEW IF EXISTS public.v_user_order_summary CASCADE;

-- 2. ปลด Foreign Key Constraints ทั้งหมดที่ผูกกับตารางที่จะแปลงเป็น TEXT
ALTER TABLE IF EXISTS public.manual_topups DROP CONSTRAINT IF EXISTS manual_topups_channel_id_fkey;
ALTER TABLE IF EXISTS public.coupon_redemptions DROP CONSTRAINT IF EXISTS coupon_redemptions_coupon_id_fkey;

-- 3. ปรับประเภทคอลัมน์ id และ foreign keys ทุกจุดให้เป็น TEXT
ALTER TABLE IF EXISTS public.manual_topups ALTER COLUMN channel_id TYPE text;
ALTER TABLE IF EXISTS public.manual_topups ALTER COLUMN id TYPE text;

ALTER TABLE IF EXISTS public.coupon_redemptions ALTER COLUMN coupon_id TYPE text;
ALTER TABLE IF EXISTS public.coupon_redemptions ALTER COLUMN id TYPE text;

ALTER TABLE IF EXISTS public.payment_channels ALTER COLUMN id TYPE text;
ALTER TABLE IF EXISTS public.coupons ALTER COLUMN id TYPE text;
ALTER TABLE IF EXISTS public.product_keys ALTER COLUMN id TYPE text;
ALTER TABLE IF EXISTS public.news_posts ALTER COLUMN id TYPE text;
ALTER TABLE IF EXISTS public.support_links ALTER COLUMN id TYPE text;
ALTER TABLE IF EXISTS public.site_settings ALTER COLUMN id TYPE text;

-- 4. ปลดล็อก NOT NULL amount ใน coupons
ALTER TABLE IF EXISTS public.coupons ALTER COLUMN amount DROP NOT NULL;

-- 5. เติมคอลัมน์ที่จำเป็นสำหรับ news_posts และ support_links
ALTER TABLE IF EXISTS public.news_posts ADD COLUMN IF NOT EXISTS pinned BOOLEAN DEFAULT FALSE;
ALTER TABLE IF EXISTS public.news_posts ADD COLUMN IF NOT EXISTS image_url TEXT DEFAULT '';
ALTER TABLE IF EXISTS public.support_links ADD COLUMN IF NOT EXISTS label TEXT DEFAULT '';
ALTER TABLE IF EXISTS public.support_links ADD COLUMN IF NOT EXISTS description TEXT DEFAULT '';
ALTER TABLE IF EXISTS public.support_links ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- 6. ผูก Foreign Keys กลับมาใหม่ (แบบปลอดภัย ชนิด TEXT)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'manual_topups') THEN
    ALTER TABLE public.manual_topups 
      ADD CONSTRAINT manual_topups_channel_id_fkey 
      FOREIGN KEY (channel_id) REFERENCES public.payment_channels(id) ON DELETE SET NULL;
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'coupon_redemptions') THEN
    ALTER TABLE public.coupon_redemptions 
      ADD CONSTRAINT coupon_redemptions_coupon_id_fkey 
      FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON DELETE CASCADE;
  END IF;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- 7. สร้าง Views กลับคืนมาใหม่ (อิงคอลัมน์ product JSONB จริง)
CREATE OR REPLACE VIEW public.v_manual_topups AS
SELECT
  mt.*,
  u.username,
  pc.name  AS channel_name,
  pc.type  AS channel_type
FROM public.manual_topups mt
LEFT JOIN public.users u ON u.id = mt.user_id
LEFT JOIN public.payment_channels pc ON pc.id = mt.channel_id;

CREATE OR REPLACE VIEW public.v_orders AS
SELECT
  o.*,
  u.username,
  COALESCE(o.product->>'name', '') AS product_name
FROM public.orders o
LEFT JOIN public.users u ON u.id = o.user_id;

-- 8. เปิดและยืนยันสิทธิ์ RLS ให้ Anon/Public อ่าน-เขียนได้ครบถ้วน
ALTER TABLE IF EXISTS public.product_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.news_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.payment_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.manual_topups ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public.support_links ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "allow_all_keys" ON public.product_keys;
CREATE POLICY "allow_all_keys" ON public.product_keys FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_coupons" ON public.coupons;
CREATE POLICY "allow_all_coupons" ON public.coupons FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_news" ON public.news_posts;
CREATE POLICY "allow_all_news" ON public.news_posts FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_channels" ON public.payment_channels;
CREATE POLICY "allow_all_channels" ON public.payment_channels FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_settings" ON public.site_settings;
CREATE POLICY "allow_all_settings" ON public.site_settings FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_manual_topups" ON public.manual_topups;
CREATE POLICY "allow_all_manual_topups" ON public.manual_topups FOR ALL TO public USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "allow_all_support_links" ON public.support_links;
CREATE POLICY "allow_all_support_links" ON public.support_links FOR ALL TO public USING (true) WITH CHECK (true);
