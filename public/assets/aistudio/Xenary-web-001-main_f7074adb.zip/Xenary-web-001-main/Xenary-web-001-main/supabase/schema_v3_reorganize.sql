-- ============================================================
--  XENARY  -  Backend Reorganize v3  (run in Supabase SQL Editor)
--  Run AFTER schema.sql + migration_v2.sql.  Idempotent: safe to re-run.
--
--  What this does
--   1. Widen users.balance / topups.amount  integer -> bigint
--      (integer caps at 2,147,483,647; current admin balances are 2,000,000,000)
--   2. Fix fn_protect_balance (old version blocked service_role when
--      app.user_id was NULL) and rebuild fn_add/deduct_balance for bigint
--   3. Append-only balance_ledger + fn_admin_adjust_balance (atomic)
--   4. Fix fn_expire_sessions (app stores exp in MILLISECONDS)
--   5. Partition audit_log by month (large, append-only table)
--   6. Index cleanup + BRIN indexes + autovacuum tuning for big tables
--   7. fn_maintenance() scheduled with pg_cron (if available)
--   8. Size / health-check queries
--
--  Disk space: Supabase disk size (100GB+) is NOT changed by SQL.
--  Dashboard > Project Settings > Compute and Disk > Disk size.
--  Self-hosted Postgres: see the optional section at the bottom.
-- ============================================================

begin;

create extension if not exists pgcrypto;
create extension if not exists pg_trgm;


-- ============================================================
-- 1. WIDEN MONEY COLUMNS  (views must be dropped and recreated)
-- ============================================================
drop view if exists v_orders;
drop view if exists v_topups;
drop view if exists v_user_order_summary;

alter table users  alter column balance type bigint;
alter table topups alter column amount  type bigint;

-- security_invoker: views obey the caller's RLS instead of the owner's
create view v_orders with (security_invoker = true) as
select o.*, u.username, u.balance as user_balance
from orders o
left join users u on u.id = o.user_id;

create view v_topups with (security_invoker = true) as
select t.*, u.username, u.balance as user_balance
from topups t
join users u on u.id = t.uid;

create view v_user_order_summary with (security_invoker = true) as
select
  u.id as user_id, u.username, u.balance,
  count(o.id)                as total_orders,
  coalesce(sum(o.total), 0)  as total_spent
from users u
left join orders o on o.user_id = u.id and o.status in ('paid','completed')
group by u.id, u.username, u.balance;

alter view if exists v_products set (security_invoker = true);
alter view if exists v_manual_topups set (security_invoker = true);


-- ============================================================
-- 2. BALANCE PROTECTION + ADD / DEDUCT
-- ============================================================
-- Direct balance/role edits are allowed only for service_role or a direct
-- SQL session (no JWT). anon / authenticated JWTs are rejected.
create or replace function fn_protect_balance()
returns trigger language plpgsql security definer set search_path = public as $fn$
declare
  v_role text;
begin
  v_role := coalesce(
    nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role',
    nullif(current_setting('request.jwt.claim.role', true), ''),
    ''
  );
  if v_role in ('', 'service_role') then
    return new;
  end if;
  if new.balance is distinct from old.balance then
    raise exception 'ไม่อนุญาตให้แก้ไข balance โดยตรง';
  end if;
  if new.role is distinct from old.role then
    raise exception 'ไม่อนุญาตให้แก้ไข role โดยตรง';
  end if;
  return new;
end;
$fn$;

drop trigger if exists trg_users_protect_balance on users;
create trigger trg_users_protect_balance
  before update on users
  for each row execute function fn_protect_balance();

create or replace function fn_add_balance(p_user_id text, p_amount numeric)
returns numeric language plpgsql security definer set search_path = public as $fn$
declare v_new bigint;
begin
  if p_amount <= 0 then
    raise exception 'amount must be positive';
  end if;
  update users
     set balance    = balance + p_amount::bigint,
         updated_at = now()
   where id = p_user_id
  returning balance into v_new;
  if not found then
    raise exception 'user not found: %', p_user_id;
  end if;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_user_id, 'balance.credit', 'user', p_user_id,
          jsonb_build_object('amount', p_amount, 'new_balance', v_new));
  return v_new;
end;
$fn$;

create or replace function fn_deduct_balance(p_user_id text, p_amount numeric)
returns numeric language plpgsql security definer set search_path = public as $fn$
declare v_new bigint;
begin
  if p_amount <= 0 then
    raise exception 'amount must be positive';
  end if;
  update users
     set balance    = balance - p_amount::bigint,
         updated_at = now()
   where id = p_user_id
     and balance >= p_amount::bigint
  returning balance into v_new;
  if not found then
    raise exception 'insufficient_balance';
  end if;
  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_user_id, 'balance.debit', 'user', p_user_id,
          jsonb_build_object('amount', p_amount, 'new_balance', v_new));
  return v_new;
end;
$fn$;


-- ============================================================
-- 3. BALANCE LEDGER + ATOMIC ADMIN ADJUST
-- ============================================================
create table if not exists balance_ledger (
  id            bigint generated always as identity primary key,
  user_id       text        not null,          -- no FK: history must survive user deletion
  delta         bigint      not null,
  balance_after bigint      not null check (balance_after >= 0),
  reason        text        not null,
  actor_id      text,
  ref_id        text,
  created_at    timestamptz not null default now()
);
create index if not exists idx_ledger_user_time on balance_ledger (user_id, created_at desc);
create index if not exists brin_ledger_created  on balance_ledger using brin (created_at);
alter table balance_ledger enable row level security;

-- p_set not null  -> set balance to p_set      (p_delta ignored)
-- p_set null      -> balance += p_delta        (negative = deduct)
create or replace function fn_admin_adjust_balance(
  p_user_id text,
  p_delta   bigint  default null,
  p_set     bigint  default null,
  p_actor   text    default null,
  p_reason  text    default 'admin.adjust'
)
returns bigint language plpgsql security definer set search_path = public as $fn$
declare
  v_old bigint;
  v_new bigint;
begin
  if p_set is null and (p_delta is null or p_delta = 0) then
    raise exception 'bad_amount';
  end if;

  select balance into v_old from users where id = p_user_id for update;
  if not found then
    raise exception 'user_not_found';
  end if;

  v_new := coalesce(p_set, v_old + p_delta);
  if v_new < 0 then
    raise exception 'insufficient_balance (current: %)', v_old;
  end if;

  update users set balance = v_new, updated_at = now() where id = p_user_id;

  insert into balance_ledger (user_id, delta, balance_after, reason, actor_id)
  values (p_user_id, v_new - v_old, v_new, p_reason, p_actor);

  insert into audit_log (actor_id, action, target_type, target_id, old_data, new_data)
  values (p_actor, 'balance.admin_adjust', 'user', p_user_id,
          jsonb_build_object('balance', v_old), jsonb_build_object('balance', v_new));

  return v_new;
end;
$fn$;

revoke all on function fn_admin_adjust_balance(text, bigint, bigint, text, text) from public, anon, authenticated;
grant execute on function fn_admin_adjust_balance(text, bigint, bigint, text, text) to service_role;
revoke all on function fn_add_balance(text, numeric)    from public, anon, authenticated;
revoke all on function fn_deduct_balance(text, numeric) from public, anon, authenticated;
grant execute on function fn_add_balance(text, numeric)    to service_role;
grant execute on function fn_deduct_balance(text, numeric) to service_role;


-- ============================================================
-- 4. SESSION / TOPUP EXPIRY  (sessions.exp is epoch MILLISECONDS)
-- ============================================================
create or replace function fn_expire_sessions()
returns integer language plpgsql as $fn$
declare v_count integer;
begin
  delete from sessions where exp < (extract(epoch from now()) * 1000)::bigint;
  get diagnostics v_count = row_count;
  return v_count;
end;
$fn$;


-- ============================================================
-- 5. AUDIT_LOG  ->  PARTITIONED BY MONTH
-- ============================================================
create or replace function fn_ensure_audit_partitions(
  p_from         date    default null,
  p_months_ahead integer default 3
)
returns integer language plpgsql as $fn$
declare
  v_start date := date_trunc('month', coalesce(p_from, current_date))::date;
  v_end   date := (date_trunc('month', current_date) + make_interval(months => p_months_ahead))::date;
  v_name  text;
  v_made  integer := 0;
begin
  while v_start <= v_end loop
    v_name := 'audit_log_' || to_char(v_start, 'YYYY_MM');
    if to_regclass('public.' || v_name) is null then
      execute format(
        'create table public.%I partition of public.audit_log for values from (%L) to (%L)',
        v_name, v_start, (v_start + interval '1 month')::date
      );
      v_made := v_made + 1;
    end if;
    v_start := (v_start + interval '1 month')::date;
  end loop;
  return v_made;
end;
$fn$;

do $mig$
declare
  r record;
begin
  if exists (
    select 1 from pg_partitioned_table p
    join pg_class c on c.oid = p.partrelid
    where c.relname = 'audit_log' and c.relnamespace = 'public'::regnamespace
  ) then
    raise notice 'audit_log already partitioned - skipping';
    return;
  end if;

  alter table audit_log rename to audit_log_legacy;
  for r in select indexname from pg_indexes
           where schemaname = 'public' and tablename = 'audit_log_legacy' loop
    execute format('alter index public.%I rename to %I', r.indexname, r.indexname || '_legacy');
  end loop;

  create table audit_log (
    id          bigint generated by default as identity,
    actor_id    text,
    action      text        not null,
    target_type text,
    target_id   text,
    old_data    jsonb,
    new_data    jsonb,
    ip          text,
    created_at  timestamptz not null default now(),
    primary key (id, created_at)
  ) partition by range (created_at);

  create table audit_log_default partition of audit_log default;

  perform fn_ensure_audit_partitions(
    (select min(created_at)::date from audit_log_legacy), 3
  );

  insert into audit_log (id, actor_id, action, target_type, target_id, old_data, new_data, ip, created_at)
  overriding system value
  select id, actor_id, action, target_type, target_id, old_data, new_data, ip, created_at
  from audit_log_legacy;

  perform setval(
    pg_get_serial_sequence('public.audit_log', 'id'),
    coalesce((select max(id) from audit_log), 0) + 1,
    false
  );
end;
$mig$;

alter table audit_log enable row level security;
create index if not exists idx_audit_actor_time on audit_log (actor_id, created_at desc);
create index if not exists idx_audit_target     on audit_log (target_type, target_id);
create index if not exists brin_audit_created   on audit_log using brin (created_at);
select fn_ensure_audit_partitions(null, 3);

-- Manual retention (NOT scheduled): drops whole monthly partitions older than N months.
create or replace function fn_drop_old_audit_partitions(p_keep_months integer)
returns integer language plpgsql as $fn$
declare
  r        record;
  v_cutoff date := (date_trunc('month', current_date) - make_interval(months => p_keep_months))::date;
  v_n      integer := 0;
begin
  if p_keep_months < 6 then
    raise exception 'keep at least 6 months of audit_log';
  end if;
  for r in
    select c.relname
    from pg_inherits i
    join pg_class c on c.oid = i.inhrelid
    where i.inhparent = 'public.audit_log'::regclass
      and c.relname ~ '^audit_log_[0-9]{4}_[0-9]{2}$'
      and to_date(substring(c.relname from '[0-9]{4}_[0-9]{2}$'), 'YYYY_MM') < v_cutoff
  loop
    execute format('drop table public.%I', r.relname);
    v_n := v_n + 1;
  end loop;
  return v_n;
end;
$fn$;
revoke all on function fn_drop_old_audit_partitions(integer) from public, anon, authenticated;


-- ============================================================
-- 6. INDEXES + STORAGE PARAMETERS
-- ============================================================
-- redundant: covered by UNIQUE constraints / composite prefixes
drop index if exists idx_users_username;
drop index if exists idx_products_slug;
drop index if exists idx_orders_user_id;
drop index if exists idx_topups_uid;

create index if not exists idx_orders_user_time on orders (user_id, created_at desc);
create index if not exists idx_topups_uid_time  on topups (uid, created_at desc);
create index if not exists brin_orders_created  on orders using brin (created_at);
create index if not exists brin_topups_created  on topups using brin (created_at);

-- users / sessions take constant small updates -> leave room for HOT updates
alter table users    set (fillfactor = 85, autovacuum_vacuum_scale_factor = 0.02, autovacuum_analyze_scale_factor = 0.01);
alter table sessions set (fillfactor = 80, autovacuum_vacuum_scale_factor = 0.02, autovacuum_analyze_scale_factor = 0.01);
alter table orders   set (autovacuum_vacuum_scale_factor = 0.05, autovacuum_analyze_scale_factor = 0.02);
alter table topups   set (autovacuum_vacuum_scale_factor = 0.05, autovacuum_analyze_scale_factor = 0.02);


-- ============================================================
-- 7. MAINTENANCE JOB
-- ============================================================
create or replace function fn_maintenance()
returns jsonb language plpgsql as $fn$
declare
  v_sessions integer;
  v_topups   integer;
  v_parts    integer;
begin
  v_sessions := fn_expire_sessions();
  v_topups   := fn_expire_topups();
  v_parts    := fn_ensure_audit_partitions(null, 3);
  return jsonb_build_object('sessions_expired', v_sessions, 'topups_expired', v_topups, 'partitions_created', v_parts);
end;
$fn$;
revoke all on function fn_maintenance() from public, anon, authenticated;
grant execute on function fn_maintenance() to service_role;

commit;

-- pg_cron outside the transaction: a missing extension must not roll back the rest.
do $cron$
begin
  create extension if not exists pg_cron;
  begin
    perform cron.unschedule('xenary_maintenance');
  exception when others then
    null;
  end;
  perform cron.schedule('xenary_maintenance', '*/10 * * * *', 'select public.fn_maintenance()');
  raise notice 'pg_cron job xenary_maintenance scheduled (every 10 min)';
exception when others then
  raise notice 'pg_cron not scheduled (%). Enable it in Dashboard > Database > Extensions, then re-run this block.', sqlerrm;
end;
$cron$;

-- Reclaim planner stats after the type changes
analyze users;
analyze topups;
analyze orders;


-- ============================================================
-- 8. SIZE / HEALTH CHECKS  (run any time)
-- ============================================================
-- Database size
--   select pg_size_pretty(pg_database_size(current_database()));
-- Biggest tables (data + indexes)
--   select relname, pg_size_pretty(pg_total_relation_size(oid)) as total
--   from pg_class where relkind in ('r','p') and relnamespace = 'public'::regnamespace
--   order by pg_total_relation_size(oid) desc limit 15;
-- Dead tuples / last autovacuum
--   select relname, n_live_tup, n_dead_tup, last_autovacuum from pg_stat_user_tables order by n_dead_tup desc;
-- Partitions
--   select inhrelid::regclass from pg_inherits where inhparent = 'public.audit_log'::regclass order by 1;
-- Cron job status
--   select * from cron.job where jobname = 'xenary_maintenance';
-- After verifying audit_log copied correctly, reclaim the old copy (irreversible):
--   select (select count(*) from audit_log) as new_rows, (select count(*) from audit_log_legacy) as old_rows;
--   drop table audit_log_legacy;


-- ============================================================
-- OPTIONAL (self-hosted Postgres only; not for Supabase)
-- ============================================================
-- Put data on the 100GB+ volume (create the directory first, owned by postgres):
--   create tablespace xenary_data location '/mnt/data100g/pg';
--   alter database postgres set default_tablespace = xenary_data;
-- Tuning example for 16GB RAM / SSD (needs a restart; run outside a transaction):
--   alter system set shared_buffers = '4GB';
--   alter system set effective_cache_size = '12GB';
--   alter system set maintenance_work_mem = '1GB';
--   alter system set work_mem = '32MB';
--   alter system set max_wal_size = '8GB';
--   alter system set random_page_cost = 1.1;
--   alter system set autovacuum_max_workers = 5;
