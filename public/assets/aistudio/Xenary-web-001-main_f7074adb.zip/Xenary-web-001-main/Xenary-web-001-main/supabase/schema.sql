-- ============================================================
--  XENARY SITE  –  Full Production Schema
--  Run in: Supabase SQL Editor (run all at once or section by section)
-- ============================================================

-- ------------------------------------------------------------
-- 0. Extensions
-- ------------------------------------------------------------
create extension if not exists "pgcrypto";
create extension if not exists "pg_trgm";


-- ============================================================
-- 1. MIGRATIONS  (ALTER existing tables first — idempotent)
--    These run before CREATE TABLE so the rest of the script
--    works whether the DB is brand-new or already has tables.
-- ============================================================

-- Rename desc → description to avoid the reserved keyword
do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_name = 'products' and column_name = 'desc'
  ) then
    alter table products rename column "desc" to description;
  end if;
end;
$$;

-- products: new columns
alter table products
  add column if not exists description text,
  add column if not exists active       boolean     not null default true,
  add column if not exists updated_at   timestamptz not null default now();

-- users: new columns
alter table users
  add column if not exists role         text        not null default 'user',
  add column if not exists banned       boolean     not null default false,
  add column if not exists ban_reason   text,
  add column if not exists updated_at   timestamptz not null default now();

-- Add check constraint on role if it doesn't exist yet
do $$
begin
  if not exists (
    select 1 from information_schema.table_constraints
    where table_name = 'users' and constraint_name = 'users_role_check'
  ) then
    alter table users
      add constraint users_role_check
      check (role in ('user','admin','moderator'));
  end if;
end;
$$;

-- sessions: new columns
alter table sessions
  add column if not exists ip         text,
  add column if not exists user_agent text;

-- orders: new columns
alter table orders
  add column if not exists note       text,
  add column if not exists updated_at timestamptz not null default now();

-- topups: new columns
alter table topups
  add column if not exists updated_at timestamptz not null default now();


-- ============================================================
-- 2. TABLES  (create only if they don't exist yet)
-- ============================================================

-- ------------------------------------------------------------
-- 2.1 products
-- ------------------------------------------------------------
create table if not exists products (
  id          text          primary key,
  slug        text          unique not null,
  channel     text,
  name        text          not null,
  tag         text,
  description text,
  stock       integer       not null default 0  check (stock >= 0),
  sold        integer       not null default 0  check (sold  >= 0),
  best_seller boolean       not null default false,
  featured    boolean       not null default false,
  active      boolean       not null default true,
  img         text,
  plans       jsonb         not null default '[]'::jsonb,
  created_at  timestamptz   not null default now(),
  updated_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.2 users
-- ------------------------------------------------------------
create table if not exists users (
  id          text          primary key,
  username    text          unique not null,
  pass        text          not null,
  balance     integer       not null default 0   check (balance >= 0),
  role        text          not null default 'user'
                check (role in ('user','admin','moderator')),
  banned      boolean       not null default false,
  ban_reason  text,
  created_at  timestamptz   not null default now(),
  updated_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.3 sessions
-- ------------------------------------------------------------
create table if not exists sessions (
  id          text          primary key,
  h           text          unique not null,
  uid         text          not null references users(id) on delete cascade,
  exp         bigint        not null,
  ip          text,
  user_agent  text,
  created_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.4 orders
-- ------------------------------------------------------------
create table if not exists orders (
  id          text          primary key,
  user_id     text          references users(id) on delete set null,
  status      text          not null default 'paid'
                check (status in ('pending','paid','processing','completed','cancelled','refunded')),
  product     jsonb         not null default '{}'::jsonb,
  plan        jsonb         not null default '{}'::jsonb,
  unit_price  numeric(12,2) not null default 0   check (unit_price >= 0),
  quantity    integer       not null default 1    check (quantity  >= 1),
  total       numeric(12,2) not null default 0   check (total     >= 0),
  currency    text          not null default '฿',
  contact     text,
  note        text,
  created_at  timestamptz   not null default now(),
  paid_at     timestamptz,
  updated_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.5 topups
-- ------------------------------------------------------------
create table if not exists topups (
  id          text          primary key,
  uid         text          not null references users(id) on delete cascade,
  method      text          not null
                check (method in ('promptpay','truemoney','admin','other')),
  amount      integer       not null default 0   check (amount > 0),
  status      text          not null default 'pending'
                check (status in ('pending','approved','rejected','expired')),
  ref         text,
  note        text,
  created_at  timestamptz   not null default now(),
  expires_at  timestamptz,
  updated_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.6 audit_log
-- ------------------------------------------------------------
create table if not exists audit_log (
  id          bigserial     primary key,
  actor_id    text,
  action      text          not null,
  target_type text,
  target_id   text,
  old_data    jsonb,
  new_data    jsonb,
  ip          text,
  created_at  timestamptz   not null default now()
);

-- ------------------------------------------------------------
-- 2.7 notifications
-- ------------------------------------------------------------
create table if not exists notifications (
  id          bigserial     primary key,
  uid         text          not null references users(id) on delete cascade,
  type        text          not null,
  title       text          not null,
  body        text,
  read        boolean       not null default false,
  ref_id      text,
  created_at  timestamptz   not null default now()
);


-- ============================================================
-- 3. INDEXES
-- ============================================================

-- products
create index if not exists idx_products_slug        on products (slug);
create index if not exists idx_products_tag         on products (tag);
create index if not exists idx_products_active      on products (active)   where active = true;
create index if not exists idx_products_featured    on products (featured) where featured = true;
create index if not exists idx_products_name_trgm   on products using gin (name gin_trgm_ops);
create index if not exists idx_products_desc_trgm   on products using gin (description gin_trgm_ops);

-- users
create index if not exists idx_users_username       on users (username);
create index if not exists idx_users_role           on users (role);

-- sessions
create index if not exists idx_sessions_uid         on sessions (uid);
create index if not exists idx_sessions_exp         on sessions (exp);

-- orders
create index if not exists idx_orders_user_id       on orders (user_id);
create index if not exists idx_orders_status        on orders (status);
create index if not exists idx_orders_created_at    on orders (created_at desc);
create index if not exists idx_orders_user_status   on orders (user_id, status);

-- topups
create index if not exists idx_topups_uid           on topups (uid);
create index if not exists idx_topups_status        on topups (status);
create index if not exists idx_topups_created_at    on topups (created_at desc);
create index if not exists idx_topups_uid_status    on topups (uid, status);

-- audit_log
create index if not exists idx_audit_actor          on audit_log (actor_id);
create index if not exists idx_audit_target         on audit_log (target_type, target_id);
create index if not exists idx_audit_created_at     on audit_log (created_at desc);

-- notifications
create index if not exists idx_notif_uid            on notifications (uid);
create index if not exists idx_notif_uid_unread     on notifications (uid, read) where read = false;


-- ============================================================
-- 4. TRIGGERS  (auto-update updated_at)
-- ============================================================

create or replace function fn_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare
  t text;
begin
  foreach t in array array['products','users','orders','topups'] loop
    execute format(
      'create or replace trigger trg_%s_updated_at
       before update on %s
       for each row execute function fn_set_updated_at();',
      t, t
    );
  end loop;
end;
$$;


-- ============================================================
-- 5. HELPER FUNCTIONS
-- ============================================================

-- 5.1  Approve topup — credit balance atomically
create or replace function fn_approve_topup(
  p_topup_id  text,
  p_actor_id  text default null
)
returns void language plpgsql security definer as $$
declare
  v_topup topups%rowtype;
begin
  select * into v_topup from topups where id = p_topup_id for update;
  if not found then
    raise exception 'topup not found: %', p_topup_id;
  end if;
  if v_topup.status <> 'pending' then
    raise exception 'topup % is not pending (status: %)', p_topup_id, v_topup.status;
  end if;

  update users  set balance = balance + v_topup.amount where id = v_topup.uid;
  update topups set status = 'approved', updated_at = now() where id = p_topup_id;

  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'topup.approved', 'topup', p_topup_id,
          jsonb_build_object('uid', v_topup.uid, 'amount', v_topup.amount));
end;
$$;

-- 5.2  Reject topup
create or replace function fn_reject_topup(
  p_topup_id  text,
  p_reason    text default null,
  p_actor_id  text default null
)
returns void language plpgsql security definer as $$
declare
  v_topup topups%rowtype;
begin
  select * into v_topup from topups where id = p_topup_id for update;
  if not found then
    raise exception 'topup not found: %', p_topup_id;
  end if;
  if v_topup.status <> 'pending' then
    raise exception 'topup % is not pending (status: %)', p_topup_id, v_topup.status;
  end if;

  update topups set status = 'rejected', note = coalesce(p_reason, note), updated_at = now()
  where id = p_topup_id;

  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'topup.rejected', 'topup', p_topup_id,
          jsonb_build_object('reason', p_reason));
end;
$$;

-- 5.3  Refund order — restore balance
create or replace function fn_refund_order(
  p_order_id  text,
  p_actor_id  text default null
)
returns void language plpgsql security definer as $$
declare
  v_order orders%rowtype;
begin
  select * into v_order from orders where id = p_order_id for update;
  if not found then
    raise exception 'order not found: %', p_order_id;
  end if;
  if v_order.status not in ('paid','completed') then
    raise exception 'order % cannot be refunded (status: %)', p_order_id, v_order.status;
  end if;

  if v_order.user_id is not null then
    update users set balance = balance + v_order.total::integer where id = v_order.user_id;
  end if;
  update orders set status = 'refunded', updated_at = now() where id = p_order_id;

  insert into audit_log (actor_id, action, target_type, target_id, new_data)
  values (p_actor_id, 'order.refunded', 'order', p_order_id,
          jsonb_build_object('user_id', v_order.user_id, 'total', v_order.total));
end;
$$;

-- 5.4  Expire old sessions
create or replace function fn_expire_sessions()
returns integer language plpgsql as $$
declare v_count integer;
begin
  delete from sessions where exp < extract(epoch from now())::bigint;
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- 5.5  Expire pending topups past their deadline
create or replace function fn_expire_topups()
returns integer language plpgsql as $$
declare v_count integer;
begin
  update topups set status = 'expired', updated_at = now()
  where status = 'pending' and expires_at is not null and expires_at < now();
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- 5.6  Dashboard stats
create or replace function fn_dashboard_stats()
returns jsonb language sql stable as $$
  select jsonb_build_object(
    'total_users',        (select count(*) from users),
    'total_orders',       (select count(*) from orders),
    'total_revenue',      (select coalesce(sum(total),0) from orders where status in ('paid','completed')),
    'pending_topups',     (select count(*) from topups  where status = 'pending'),
    'orders_today',       (select count(*) from orders  where created_at >= current_date),
    'revenue_today',      (select coalesce(sum(total),0) from orders where status in ('paid','completed') and created_at >= current_date),
    'active_products',    (select count(*) from products where active = true),
    'low_stock_products', (select count(*) from products where stock <= 3 and active = true)
  );
$$;


-- ============================================================
-- 6. VIEWS
-- ============================================================

create or replace view v_orders as
select o.*, u.username, u.balance as user_balance
from orders o
left join users u on u.id = o.user_id;

create or replace view v_topups as
select t.*, u.username, u.balance as user_balance
from topups t
join users u on u.id = t.uid;

create or replace view v_products as
select
  p.*,
  (select min((pl->>'price')::numeric) from jsonb_array_elements(p.plans) pl) as min_price,
  (select max((pl->>'price')::numeric) from jsonb_array_elements(p.plans) pl) as max_price,
  jsonb_array_length(p.plans) as plan_count
from products p
where p.active = true;

create or replace view v_user_order_summary as
select
  u.id as user_id, u.username, u.balance,
  count(o.id)                as total_orders,
  coalesce(sum(o.total), 0)  as total_spent
from users u
left join orders o on o.user_id = u.id and o.status in ('paid','completed')
group by u.id, u.username, u.balance;


-- ============================================================
-- 7. ROW LEVEL SECURITY
-- ============================================================

alter table users         enable row level security;
alter table sessions      enable row level security;
alter table orders        enable row level security;
alter table topups        enable row level security;
alter table notifications enable row level security;
alter table audit_log     enable row level security;
alter table products      enable row level security;

-- Drop existing policies before recreating (idempotent)
do $$
declare pol record;
begin
  for pol in
    select policyname, tablename from pg_policies
    where schemaname = 'public'
      and tablename in ('products','users','sessions','orders','topups','notifications','audit_log')
  loop
    execute format('drop policy if exists %I on %I', pol.policyname, pol.tablename);
  end loop;
end;
$$;

-- products: public read, service_role write
create policy "products_public_read"
  on products for select using (active = true);

create policy "products_service_write"
  on products for all to service_role
  using (true) with check (true);

-- users
create policy "users_own_row"
  on users for select
  using (id = current_setting('app.user_id', true));

create policy "users_insert_anon"
  on users for insert
  to anon
  with check (true);

create policy "users_service_all"
  on users for all to service_role
  using (true) with check (true);

-- sessions
create policy "sessions_own"
  on sessions for select
  using (uid = current_setting('app.user_id', true));

create policy "sessions_insert_anon"
  on sessions for insert
  to anon
  with check (true);

create policy "sessions_delete_anon"
  on sessions for delete
  to anon
  using (true);

create policy "sessions_service_all"
  on sessions for all to service_role
  using (true) with check (true);

-- orders
create policy "orders_own"
  on orders for select
  using (user_id = current_setting('app.user_id', true));

create policy "orders_service_all"
  on orders for all to service_role
  using (true) with check (true);

-- topups
create policy "topups_own"
  on topups for select
  using (uid = current_setting('app.user_id', true));

create policy "topups_service_all"
  on topups for all to service_role
  using (true) with check (true);

-- notifications
create policy "notifications_own_read"
  on notifications for select
  using (uid = current_setting('app.user_id', true));

create policy "notifications_own_update"
  on notifications for update
  using (uid = current_setting('app.user_id', true));

create policy "notifications_service_all"
  on notifications for all to service_role
  using (true) with check (true);

-- audit_log
create policy "audit_log_service_all"
  on audit_log for all to service_role
  using (true) with check (true);


-- ============================================================
-- 8. SEED DATA
-- ============================================================

insert into products (id, slug, channel, name, tag, description, stock, sold, best_seller, featured, img, plans)
values
  (
    'aim-color', 'aim-color', 'a1m-color', 'VAL AIM COLOR', 'Valorant',
    'Color and model presets with instant in-game swapping.',
    29, 25, true, true,
    'https://img2.pic.in.th/serifaimcolor3.png',
    '[
      {"label":"1 Day",    "price":59,  "per":"/day"},
      {"label":"7 Days",   "price":159, "per":"/week"},
      {"label":"1 Month",  "price":359, "per":"/month"},
      {"label":"Lifetime", "price":999, "per":"one-time"}
    ]'::jsonb
  ),
  (
    'v0l-external', 'v0l-external', 'v0l-external', 'VAL External', 'Valorant',
    'Valorant external build with instant delivery.',
    10, 0, false, true,
    null,
    '[
      {"label":"1 Day",    "price":220,  "per":"/day"},
      {"label":"3 Days",   "price":480,  "per":"/3 days"},
      {"label":"1 Week",   "price":790,  "per":"/week"},
      {"label":"1 Month",  "price":1590, "per":"/month"},
      {"label":"Lifetime", "price":3200, "per":"one-time"}
    ]'::jsonb
  )
on conflict (slug) do update set
  channel     = excluded.channel,
  name        = excluded.name,
  tag         = excluded.tag,
  description = excluded.description,
  stock       = excluded.stock,
  sold        = excluded.sold,
  best_seller = excluded.best_seller,
  featured    = excluded.featured,
  img         = excluded.img,
  plans       = excluded.plans;


-- ============================================================
-- 9. USEFUL ADMIN QUERIES  (uncomment to run)
-- ============================================================

-- Dashboard stats
-- select fn_dashboard_stats();

-- Pending topups (newest first)
-- select * from v_topups where status = 'pending' order by created_at desc;

-- Orders today
-- select * from v_orders where created_at >= current_date order by created_at desc;

-- Top spenders
-- select * from v_user_order_summary order by total_spent desc limit 20;

-- Low stock
-- select id, name, stock from products where stock <= 3 and active = true order by stock;

-- Search product by name
-- select * from products where name ilike '%val%';

-- Approve / Reject topup
-- select fn_approve_topup('<topup_id>', '<admin_id>');
-- select fn_reject_topup('<topup_id>', 'invalid QR', '<admin_id>');

-- Refund order
-- select fn_refund_order('<order_id>', '<admin_id>');

-- Expire old sessions & topups
-- select fn_expire_sessions();
-- select fn_expire_topups();

-- Recent audit log
-- select * from audit_log order by created_at desc limit 50;

-- Adjust balance manually
-- update users set balance = balance + 500 where username = 'somchai';

-- Ban user
-- update users set banned = true, ban_reason = 'TOS violation' where username = 'somchai';

-- Revenue by month (last 12 months)
-- select
--   date_trunc('month', created_at) as month,
--   count(*)    as orders,
--   sum(total)  as revenue
-- from orders
-- where status in ('paid','completed')
--   and created_at >= now() - interval '12 months'
-- group by 1 order by 1 desc;

-- Unread notifications for a user
-- select * from notifications where uid = '<user_id>' and read = false order by created_at desc;
